<?php
include "z_db.php";
$username = $_SESSION['username'];
?>
<div class="app-menu navbar-menu">
    <!-- LOGO -->
    <div class="navbar-brand-box">
        <!-- Dark Logo-->
        <!-- <img src="./Dynamic (1).png" alt="" srcset=""> -->

        <a href="index.html" class="logo logo-dark">
            <span class="logo-sm">
                <img src="./Dynamic (1).png" alt="" height="22">
            </span>
            <span class="logo-lg">
                <img src="./Dynamic (1).png" alt="" height="30">
            </span>
        </a>
        <!-- Light Logo-->
        <a href="index.html" class="logo logo-light">
            <span class="logo-sm">
                <img src="./Dynamic (1).png" alt="" height="22">
            </span>
            <span class="logo-lg">
                <img src="./Dynamic (1).png" alt="" height="30">
            </span>
        </a>
        <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover" id="vertical-hover">
            <i class="ri-record-circle-line"></i>
        </button>
    </div>

    <div id="scrollbar">
        <div class="container-fluid">

            <div id="two-column-menu">
            </div>
            <ul class="navbar-nav" id="navbar-nav">
                <li class="menu-title"><span data-key="t-menu">Menu</span></li>


                <li class="nav-item">
                    <a href="dashboard" class="nav-link" data-key="t-analytics"> <i class="ri-dashboard-2-line"></i> <span data-key="t-dashboards"> Dashboard </span></a>




                </li>

                <!-- <li class="nav-item">
                                <a class="nav-link menu-link" href="#sidebarB" data-bs-toggle="collapse" role="button" aria-expanded="true" aria-controls="sidebarLanding">
                                    <i class="ri-file-list-3-line"></i> <span data-key="t-landing">Manage Speed your flow</span>
                                </a>
                                <div class="menu-dropdown collapse" id="sidebarB" style="">
                                    <ul class="nav nav-sm flex-column">
                                        
                                        <li class="nav-item">
                                            <a href="speedflow.php" class="nav-link" data-key="t-nft-landing">Speed your flow lists </a>
                </li>   </ul>
                                </div>
                            </li> -->



                <!-- <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarB" data-bs-toggle="collapse" role="button" aria-expanded="true" aria-controls="sidebarLanding">
                                <i class="ri-file-list-3-line"></i> <span data-key="t-landing">Manage Solution</span>
                            </a>
                            <div class="menu-dropdown collapse" id="sidebarB" style="">
                                <ul class="nav nav-sm flex-column">
                               
                                
                              

                                </ul>
                            </div>
                        </li> -->


                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarLanding" data-bs-toggle="collapse" role="button" aria-expanded="true" aria-controls="sidebarLanding">
                        <i class="ri-checkbox-multiple-line"></i> <span data-key="t-landing">Manage courosal</span>
                    </a>
                    <div class="menu-dropdown collapse" id="sidebarLanding" style="">
                        <ul class="nav nav-sm flex-column">
                            <li class="nav-item">
                                <a href="createservice" class="nav-link" data-key="t-one-page"> Add courosal </a>
                            </li>
                            <li class="nav-item">
                                <a href="services" class="nav-link" data-key="t-nft-landing"> courosal List </a>
                            </li>
                        </ul>
                    </div>
                </li>

                


                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarSl" data-bs-toggle="collapse" role="button" aria-expanded="true" aria-controls="sidebarLanding">
                        <i class="ri-image-fill"></i> <span data-key="t-landing">Manage Banner</span>
                    </a>
                    <div class="menu-dropdown collapse" id="sidebarSl" style="">
                        <ul class="nav nav-sm flex-column">
                            
                            <li class="nav-item">
                                <a href="static" class="nav-link" data-key="t-nft-landing"> Static Banner</a>
                            </li>
                            <li class="nav-item">
                                <a href="./nstatic.php" class="nav-link" data-key="t-nft-landing"> Our Impact</a>
                            </li>

                            
                        </ul>
                    </div>
                </li>




                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarSl" data-bs-toggle="collapse" role="button" aria-expanded="true" aria-controls="sidebarLanding">
                        <i class="ri-image-fill"></i> <span data-key="t-landing">Manage Results page</span>
                    </a>
                    <div class="menu-dropdown collapse" id="sidebarSl" style="">
                        <ul class="nav nav-sm flex-column">
                           
            
                            <li class="nav-item">
                                <a href="tech-page.php" class="nav-link" data-key="t-nft-landing">  Results page Banner</a>
                            </li>

                            
                        </ul>
                    </div>
                </li>




               

                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarT" data-bs-toggle="collapse" role="button" aria-expanded="true" aria-controls="sidebarLanding">
                        <i class="ri-message-line"></i> <span data-key="t-landing">Manage Team</span>
                    </a>
                    <div class="menu-dropdown collapse" id="sidebarT" style="">
                        <ul class="nav nav-sm flex-column">
                            <li class="nav-item">
                                <a href="newtestimony" class="nav-link" data-key="t-one-page">New Team Member</a>
                            </li>
                            <li class="nav-item">
                                <a href="testimony" class="nav-link" data-key="t-nft-landing"> All Team Member </a>
                            </li>
                        </ul>
                    </div>
                </li>



                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarT" data-bs-toggle="collapse" role="button" aria-expanded="true" aria-controls="sidebarLanding">
                        <i class="ri-message-line"></i> <span data-key="t-landing">Manage Plans</span>
                    </a>
                    <div class="menu-dropdown collapse" id="sidebarT" style="">
                        <ul class="nav nav-sm flex-column">
                        <li class="nav-item">
                                <a href="./static_plans.php" class="nav-link" data-key="t-nft-landing">You Plans</a>
                            </li>
                        </ul>
                    </div>
                </li>

                
               


                <li class="nav-item">
                    <a class="nav-link menu-link" href="#sidebarK" data-bs-toggle="collapse" role="button" aria-expanded="true" aria-controls="sidebarLanding">
                        <i class="ri-tools-fill"></i> <span data-key="t-landing"> Site Configuration </span>
                    </a>
                    <div class="menu-dropdown collapse" id="sidebarK" style="">
                        <ul class="nav nav-sm flex-column">
                            
                            <li class="nav-item">
                                <a href="contact" class="nav-link" data-key="t-nft-landing"> Update Contact </a>
                            </li>
                        </ul>
                    </div>
                </li>




                




            </ul>
        </div>
        <!-- Sidebar -->
    </div>

    <div class="sidebar-background"></div>
</div>
<!-- Left Sidebar End -->
<!-- Vertical Overlay-->
<div class="vertical-overlay"></div>