-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 11, 2024 at 05:58 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digitus`
--

-- --------------------------------------------------------

--
-- Table structure for table `aboutstatic`
--

CREATE TABLE `aboutstatic` (
  `id` int(11) NOT NULL,
  `stitle` varchar(1000) NOT NULL,
  `stext` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `aboutstatic`
--

INSERT INTO `aboutstatic` (`id`, `stitle`, `stext`, `updated_at`) VALUES
(1, 'Welcome to caregivers 24 Hospital & Healthcare', 'We take Clients as part of Family Home Nuring Care in Patna believes in treating our clients and their families with love, prestige and respect. Treating our clients like members of our extended family helps us to meet every need and strengthen your peace of mind. ', '2023-12-29 20:48:20');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updated_at`) VALUES
(1, 'admin', 'admin', '2022-07-13 11:00:19');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `subject` varchar(150) NOT NULL,
  `date` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `phone`, `email`, `subject`, `date`, `name`, `updated_at`) VALUES
(1, '06396553232', 'prafulyadav880@gmail.com', 'ehgdfuioiewhguifihvugiebihofu', '3-march-2023', 'Praful Yadav', '2024-01-02 08:24:22'),
(2, '06396553232', 'prafulyadav880@gmail.com', 'ehgdfuioiewhguifihvugiebihofu', '3-march-2023', 'Praful Yadav', '2024-01-02 08:25:21'),
(3, '06396553232', 'prafulyadav880@gmail.com', 'dgvkuqdogqdiqiodhqoih', '3-march-2023', 'Praful Yadav', '2024-01-02 08:34:18'),
(4, '06396553232', 'prafulyadav880@gmail.com', 'dgvkuqdogqdiqiodhqoih', '3-march-2023', 'Praful Yadav', '2024-01-02 08:35:39'),
(5, '06396553232', 'prafulyadav880@gmail.com', 'jkfwvfihfeoub', '3-march-2023', 'Praful Yadav', '2024-01-02 08:35:52');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `blog_title` varchar(300) NOT NULL,
  `blog_desc` varchar(2000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `blog_title`, `blog_desc`, `updated_at`) VALUES
(1, 'Integration', 'SaaS (private Cloud) or On Premise model, we install, configure or migrate your solution in the most optimal way.', '2023-11-24 14:41:25'),
(2, 'Accompaniment ', 'Regardless of your solution, installed or not by EsaLink, we offer several assistance models for the resolution or prevention of your incidents. <br><br>', '2023-11-25 07:47:25'),
(3, 'Advice', 'Digitus offers you certified EDI solutions, perfectly suited to your most specific needs and projects.<br> ', '2023-11-24 14:41:41');

-- --------------------------------------------------------

--
-- Table structure for table `blog1`
--

CREATE TABLE `blog1` (
  `id` int(11) NOT NULL,
  `blog_title` varchar(300) NOT NULL,
  `blog_desc` varchar(2000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blog1`
--

INSERT INTO `blog1` (`id`, `blog_title`, `blog_desc`, `updated_at`) VALUES
(2, 'How to Dematerialize an Invoice?sese', 'Electronic Data Interchange (EDI) is Middleware. Through its gateway function, it facilitates the communication of information between two companies. The Application Programming Interface (API), on the other hand, corresponds to specific access that is granted to the services of an application.', '2023-11-24 05:32:23'),
(3, 'How to Dematerialize an Invoice?sese', 'How to Dematerialize an Invoice?seseHow to Dematerialize an Invoice?seseHow to Dematerialize an Invoice?seseHow to Dematerialize an Invoice?sese', '2023-11-24 05:32:56');

-- --------------------------------------------------------

--
-- Table structure for table `blogd`
--

CREATE TABLE `blogd` (
  `id` int(11) NOT NULL,
  `message` varchar(300) NOT NULL,
  `date` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blogd`
--

INSERT INTO `blogd` (`id`, `message`, `date`, `name`, `ufile`, `updated_at`) VALUES
(4, 'jdhgwuihofouweghfoiew', '3-march-2023', 'testing', 'about-img1.jpg', '2024-01-02 08:55:04');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `ufile`, `updated_at`) VALUES
(1, 'sanofi', '888img1.svg', '2023-11-24 22:26:28'),
(2, 'carglass', '6635img2.svg', '2023-11-24 22:27:41'),
(3, 'nestle', '5818img3.webp', '2023-11-24 22:27:58'),
(4, 'loreal', '909img4.webp', '2023-11-24 22:28:42'),
(5, 'coliss', '2229img5.webp', '2023-11-24 22:29:19'),
(6, 'clairefontaine', '8029img6.webp', '2023-11-24 22:30:00'),
(7, 'lira', '3447img7.svg', '2023-11-24 22:30:17'),
(8, 'plastic omnium', '683img8.svg', '2023-11-24 22:30:44'),
(9, 'maccs', '7831img9.webp', '2023-11-24 22:30:58'),
(10, 'chantelle', '7651img10.webp', '2023-11-24 22:31:31'),
(11, 'exacompta', '5694img11.webp', '2023-11-24 22:32:02');

-- --------------------------------------------------------

--
-- Table structure for table `dteam`
--

CREATE TABLE `dteam` (
  `id` int(11) NOT NULL,
  `insta` varchar(300) NOT NULL,
  `post` varchar(300) NOT NULL,
  `facebook` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dteam`
--

INSERT INTO `dteam` (`id`, `insta`, `post`, `facebook`, `name`, `ufile`, `updated_at`) VALUES
(6, 'insta', 'Chairman', 'facebook', 'Ravindra Kishore', 'team-img1.jpg', '2024-01-02 07:04:46');

-- --------------------------------------------------------

--
-- Table structure for table `frontpage_banner_service`
--

CREATE TABLE `frontpage_banner_service` (
  `id` int(11) NOT NULL,
  `message` varchar(300) NOT NULL,
  `name` varchar(150) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `frontpage_banner_service`
--

INSERT INTO `frontpage_banner_service` (`id`, `message`, `name`, `ufile`, `updated_at`) VALUES
(10, 'The goal is to help the wound heal as soon as possible by using an appropriate dressing material to maintain the right amount of moisture.', 'Wound dressing', '7714pulmonary-icon.png', '2023-12-29 19:50:02'),
(14, 'A nebulizer is a small machine that turns liquid medicine into a mist that can be easily inhaled', 'Nebulization ', '2930gynecology-icon.png', '2023-12-29 19:58:57'),
(15, '\r\nA medication administration route is often classified by the location at which the drug is applied, such as oral or intravenous.', 'Administering medications', '8563pphthalmology-icon.png', '2023-12-29 20:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `logo`
--

CREATE TABLE `logo` (
  `id` int(11) NOT NULL,
  `xfile` varchar(1000) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logo`
--

INSERT INTO `logo` (`id`, `xfile`, `ufile`, `updated_at`) VALUES
(1, '3943—Pngtree—instagram icon_8704817.png', '2191—Pngtree—instagram icon_8704817.png', '2023-11-21 11:46:53');

-- --------------------------------------------------------

--
-- Table structure for table `nstatic`
--

CREATE TABLE `nstatic` (
  `id` int(11) NOT NULL,
  `stitle` varchar(150) NOT NULL,
  `stext` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `stext2` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `nstatic`
--

INSERT INTO `nstatic` (`id`, `stitle`, `stext`, `updated_at`, `stext2`) VALUES
(1, '1000', '1200', '2024-05-05 22:08:28', '130');

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` int(11) NOT NULL,
  `stitle` varchar(150) NOT NULL,
  `stext` varchar(1000) NOT NULL,
  `stext1` varchar(1000) NOT NULL,
  `stext3` varchar(1000) NOT NULL,
  `stext4` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `stext2` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`id`, `stitle`, `stext`, `stext1`, `stext3`, `stext4`, `updated_at`, `stext2`) VALUES
(1, 'Starter Pack', '1,499', 'Trial Pack', '2,799', '249', '2024-05-09 10:06:19', '2x Growth Pack');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL,
  `port_title` varchar(500) NOT NULL,
  `port_desc` varchar(1000) NOT NULL,
  `port_detail` varchar(2000) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `port_title`, `port_desc`, `port_detail`, `ufile`, `updated_at`) VALUES
(3, 'App Development', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Lorem ipsum dolor sit amet, consectetur adipisicing elit. ', '926070de04f0-df57-11ec-85a8-bda8f2c6ca77-rimg-w720-h720-gmir.jpg', '2022-07-18 14:48:54');

-- --------------------------------------------------------

--
-- Table structure for table `scnt`
--

CREATE TABLE `scnt` (
  `id` int(11) NOT NULL,
  `stext` varchar(255) DEFAULT NULL,
  `stext1` varchar(255) DEFAULT NULL,
  `stext2` varchar(255) DEFAULT NULL,
  `stext3` varchar(255) DEFAULT NULL,
  `stext4` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `scnt`
--

INSERT INTO `scnt` (`id`, `stext`, `stext1`, `stext2`, `stext3`, `stext4`, `updated_at`) VALUES
(1, '385', '71', '42', '852', 'To provide the best quality of care and customer services to our clients through the use of best practices, highly trained staff and innovative programs and services designed to meet their special needs. We take Clients as part of Family Home Nuring Care in Patna believes in treating our clients and their families with love, prestige and respect. Treating our clients like members of our extended family helps us to meet every need and strengthen your peace of mind. Employing Home Nursing Care, comes with an assurance of proper care for your loved ones.', '2023-12-29 22:57:34');

-- --------------------------------------------------------

--
-- Table structure for table `section_title`
--

CREATE TABLE `section_title` (
  `id` int(11) NOT NULL,
  `about_title` varchar(500) NOT NULL,
  `about_text` varchar(1000) NOT NULL,
  `why_title` varchar(500) NOT NULL,
  `why_text` varchar(1000) NOT NULL,
  `service_title` varchar(500) NOT NULL,
  `service_text` varchar(1000) NOT NULL,
  `port_title` varchar(500) NOT NULL,
  `port_text` varchar(1000) NOT NULL,
  `test_title` varchar(500) NOT NULL,
  `test_text` varchar(1000) NOT NULL,
  `contact_title` varchar(500) NOT NULL,
  `contact_text` varchar(1000) NOT NULL,
  `enquiry_title` varchar(500) NOT NULL,
  `enquiry_text` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `section_title`
--

INSERT INTO `section_title` (`id`, `about_title`, `about_text`, `why_title`, `why_text`, `service_title`, `service_text`, `port_title`, `port_text`, `test_title`, `test_text`, `contact_title`, `contact_text`, `enquiry_title`, `enquiry_text`) VALUES
(1, 'We help to grow your business.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.', 'Work smarter, not harder.', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.', 'We provide the best digital services', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.', 'Our Recent Works', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.', 'Our clients says', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.', 'Let\'s connect!', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.', 'Looking for the best digital agency & marketing solution?', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum obcaecati dignissimos quae quo ad iste ipsum officiis deleniti asperiores sit.');

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `service_title` varchar(500) NOT NULL,
  `upadated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `service_title`, `upadated_at`) VALUES
(3, '<iframe src=\"https://player.vimeo.com/video/886428353?h=072ed846d1&autoplay=1&loop=1&background=1\" style=\"top:0;left:0;width:100%;height:100%;\" frameborder=\"0\" allow=\"autoplay; fullscreen; picture-in-picture\" allowfullscreen> </iframe>', '2024-05-07 11:41:21'),
(4, '<iframe src=\"https://player.vimeo.com/video/886428353?h=072ed846d1&autoplay=1&loop=1&background=1\" style=\"top:0;left:0;width:100%;height:100%;\" frameborder=\"0\" allow=\"autoplay; fullscreen; picture-in-picture\" allowfullscreen> </iframe>', '2024-05-07 11:40:59'),
(6, '<iframe src=\"https://player.vimeo.com/video/886428353?h=072ed846d1&autoplay=1&loop=1&background=1\" style=\"top:0;left:0;width:100%;height:100%;\" frameborder=\"0\" allow=\"autoplay; fullscreen; picture-in-picture\" allowfullscreen> </iframe>', '2024-05-07 11:53:06');

-- --------------------------------------------------------

--
-- Table structure for table `service_page`
--

CREATE TABLE `service_page` (
  `id` int(11) NOT NULL,
  `message` varchar(300) NOT NULL,
  `date` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_page`
--

INSERT INTO `service_page` (`id`, `message`, `date`, `name`, `ufile`, `updated_at`) VALUES
(3, 'ejbfwkufhkwflw', 'efwjefbuwuofihw', 'testing', '', '2024-01-02 08:50:59'),
(4, 'wdhguqiowhdiuqhwdoiuhihdwhioqwhhdowiq', '3-march-2023', 'testing', '', '2024-01-02 08:52:14');

-- --------------------------------------------------------

--
-- Table structure for table `siteconfig`
--

CREATE TABLE `siteconfig` (
  `id` int(11) NOT NULL,
  `site_keyword` varchar(1000) NOT NULL,
  `site_title` varchar(300) NOT NULL,
  `site_about` varchar(1000) NOT NULL,
  `site_footer` varchar(1000) NOT NULL,
  `follow_text` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `siteconfig`
--

INSERT INTO `siteconfig` (`id`, `site_keyword`, `site_title`, `site_about`, `site_footer`, `follow_text`, `updated_at`) VALUES
(1, 'L3/1B, S. K. Puri, Opposite S.K.Puri Children Park, Boring Road, Patna-800 001', 'privacy policy ', ' Home Nursing Care in Patna\r\n\r\nNursing Services in Patna\r\n\r\nHome ICU Setup In Patna\r\n\r\nICU at Home Services In Patna\r\n\r\nHome Nursing Services in Bihar\r\n\r\nCOVID Care at Home Patna\r\n\r\n(10 liter) Oxygen Concentrator on Rent in Patna\r\n\r\n(5 liter) Oxygen Concentrator on Rent in Bihar\r\n\r\nPortable Oxygen Concentrator on Rent in Patna\r\n\r\nPortable Oxygen Concentrator on Rent in Bihar\r\n\r\nHospital Bed on Rent in Patna\r\n\r\nHospital Bed on Rent in Bihar\r\n\r\nMultifunctional Patient Moniter on Rent in patna\r\n\r\nMultifunctional Patient Moniter on Rent in Bihar\r\n\r\nBiPap Machine on Rent in Patna\r\n\r\nHome Care Nursing services in patna\r\n\r\nHome Nursing Services in Patna\r\n\r\nNursing Services at Home\r\n\r\nNurse Service at Home in Patna\r\n\r\nElder Care at Home\r\n\r\nECG On Rent Patna', '© 2023 All Rights Reserved  developed by Agumentik', 'terms and conditions', '2024-01-02 07:56:24');

-- --------------------------------------------------------

--
-- Table structure for table `sitecontact`
--

CREATE TABLE `sitecontact` (
  `id` int(11) NOT NULL,
  `phone1` varchar(150) NOT NULL,
  `phone2` varchar(150) NOT NULL,
  `email1` varchar(100) NOT NULL,
  `insta` varchar(100) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `twitter` varchar(150) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sitecontact`
--

INSERT INTO `sitecontact` (`id`, `phone1`, `phone2`, `email1`, `insta`, `facebook`, `twitter`, `updated_at`) VALUES
(1, '+916396553232', 'Enough of generic approach, get guaranteed results from experts.', 'prafulyadav880@gmail.com', 'https://www.instagram.com/praful_.yadav', 'https://www.linkedin.com/', '©️2024 Dynamic Frames. All Rights Reserved', '2024-05-08 13:45:57');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `slide_title` varchar(150) NOT NULL,
  `slide_text` varchar(500) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `slide_title`, `slide_text`, `ufile`, `updated_at`) VALUES
(1, 'We are digital agency & Marketing', 'Lorem ipsum dolor sit amet', '58806059d354562031616499540.png', '2023-11-24 07:31:17');

-- --------------------------------------------------------

--
-- Table structure for table `social`
--

CREATE TABLE `social` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `fa` varchar(150) NOT NULL,
  `social_link` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `social`
--

INSERT INTO `social` (`id`, `name`, `fa`, `social_link`) VALUES
(3, 'instagram', 'fab fa-instagram', 'https://www.instagram.com/praful_.yadav/');

-- --------------------------------------------------------

--
-- Table structure for table `sol`
--

CREATE TABLE `sol` (
  `id` int(11) NOT NULL,
  `blog_title` varchar(300) NOT NULL,
  `blog_desc` varchar(2000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sol`
--

INSERT INTO `sol` (`id`, `blog_title`, `blog_desc`, `updated_at`) VALUES
(1, 'Manage your EDI flows with peace of mind', 'Monitor, control and trace your financial or supply chain exchanges and at each stage of your activity.', '2023-11-22 17:18:37'),
(2, 'Take Back Control Through Flexibility', 'Streamline the integration of your new partners and start communicating without wasting time. Gain autonomy and efficiency in your commercial exchanges:', '2023-11-22 17:19:24'),
(4, 'Choose efficiency by digitalizing and automating all your B2B flows', 'Optimize and secure the functioning of your ecosystem by minimizing any human intervention. Unlock your productivity potential.', '2023-11-22 17:17:07'),
(5, 'How to Dematerialize an Invoice?', 'How to Dematerialize an Invoice?How to Dematerialize an Invoice?How to Dematerialize an Invoice?How to Dematerialize an Invoice?How to Dematerialize an Invoice?', '2023-11-22 17:52:16');

-- --------------------------------------------------------

--
-- Table structure for table `sol1`
--

CREATE TABLE `sol1` (
  `id` int(11) NOT NULL,
  `blog_title` varchar(300) NOT NULL,
  `blog_desc` varchar(2000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sol1`
--

INSERT INTO `sol1` (`id`, `blog_title`, `blog_desc`, `updated_at`) VALUES
(1, 'Switch to electronic invoicing', 'Opt now for tax dematerialization to reduce your costs and\r\n                  automate the processing of your supplier and customer\r\n                  invoices.', '2023-11-22 18:02:29'),
(2, 'Be in line with the tax regulations of tomorrow', ' Following the reform carried out by the DGFiP and the Finance\r\n                  Law, all companies will have to receive and issue their B2B\r\n                  and B2G invoices exclusively in electronic format.', '2023-11-22 18:10:59'),
(3, 'Simplify your management', ' Access a global and intelligent vision of your activity with\r\n                  real-time traceability. Optimize your commercial management', '2023-11-22 18:11:52'),
(4, '  Improve your competitiveness by managing your exchanges', ' Reduce the risks of errors and non-compliance and thus\r\n                  neutralize payment delays to the benefit of your cash flow.', '2023-11-22 18:12:19');

-- --------------------------------------------------------

--
-- Table structure for table `speedflow`
--

CREATE TABLE `speedflow` (
  `id` int(11) NOT NULL,
  `port_title` varchar(500) NOT NULL,
  `port_detail` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `speedflow`
--

INSERT INTO `speedflow` (`id`, `port_title`, `port_detail`) VALUES
(1, 'Advice', 'Through a technical-functional audit our experts diagnose your information systems and configurations.<br> <br>\r\nAt the end of this study, we establish a structured report accompanied by an action plan to respond to your Electronic Data Exchange challenges.\r\nDigitus offers you certified EDI solutions, perfectly suited to your most specific needs and projects.'),
(2, 'Accompaniment', 'Regardless of your solution, installed or not by EsaLink, we offer several assistance models for the resolution or prevention of your incidents.<br><br>\r\nRegardless of your solution, installed or not by EsaLink, we offer several assistance models for the resolution or prevention of your incidents.'),
(3, 'Integration', 'SaaS (private Cloud) or On Premise model, we install, configure or migrate your solution in the most optimal way.\r\nOur EDI experts integrate the modules in perfect symbiosis with your infrastructure and your ecosystem.\r\nWe test and apply all sensitive connections and adjustments that allow you to achieve complete satisfaction with your solution.');

-- --------------------------------------------------------

--
-- Table structure for table `static`
--

CREATE TABLE `static` (
  `id` int(11) NOT NULL,
  `stitle` varchar(150) NOT NULL,
  `stext` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `stext2` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `static`
--

INSERT INTO `static` (`id`, `stitle`, `stext`, `updated_at`, `stext2`) VALUES
(1, 'Crafting content that drive', 'Elevating Views to Revenue, Seamlessly Transforming Eyeballs into Paying Leads. Partner with us and watch your numbers and results explode.', '2024-05-05 22:00:55', 'explosive growth');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `id` int(11) NOT NULL,
  `message` varchar(300) NOT NULL,
  `date` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `techbanner`
--

CREATE TABLE `techbanner` (
  `id` int(11) NOT NULL,
  `stitle` varchar(150) NOT NULL,
  `img` varchar(150) NOT NULL,
  `stext` varchar(500) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `techbanner`
--

INSERT INTO `techbanner` (`id`, `stitle`, `img`, `stext`, `updated_at`) VALUES
(1, 'Best Technologies & Development  Agency', 'https://dmlab.edu.gr/assets/media/2019/09/Web_Development.png', 'At Digitus , we pride ourselves on being at the forefront of cutting-edge web development technologies, and ReactJS is no exception. As a leading ReactJS web development service provider, we are dedicated to helping businesses leverage the power of this robust JavaScript library to build stunning, dynamic, and high-performance web applications. We have a team of skilled ReactJS developers who are known to streamline your web development process by using reusable components.', '2023-12-11 10:39:18');

-- --------------------------------------------------------

--
-- Table structure for table `techpage`
--

CREATE TABLE `techpage` (
  `id` int(11) NOT NULL,
  `stitle` varchar(1500) NOT NULL,
  `stext` varchar(1500) NOT NULL,
  `img` varchar(1500) NOT NULL,
  `title1` varchar(1500) NOT NULL,
  `text1` varchar(500) NOT NULL,
  `client1` varchar(50) NOT NULL,
  `project1` varchar(50) NOT NULL,
  `year1` varchar(50) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `techpage`
--

INSERT INTO `techpage` (`id`, `stitle`, `stext`, `img`, `title1`, `text1`, `client1`, `project1`, `year1`, `updated_at`) VALUES
(1, '<script src=\"https://fast.wistia.com/embed/medias/t4e60u2uct.jsonp\" async></script>                                                 <script src=\"https://fast.wistia.com/assets/external/E-v1.js\" async></script>                                                 <div class=\"wistia_responsive_padding\" style=\"padding:177.78% 0 0 0;position:relative;\">                                                     <div class=\"wistia_responsive_wrapper\" style=\"height:100%;left:0;position:absolute;top:0;width:100%;\">                                                         <div class=\"wistia_embed wistia_async_t4e60u2uct seo=true videoFoam=true\" style=\"height:100%;position:relative;width:100%\">                                                             <div class=\"wistia_swatch\" style=\"height:100%;left:0;opacity:0;overflow:hidden;position:absolute;top:0;transition:opacity 200ms;width:100%;\">                                                                 <img src=\"https://fast.wistia.com/embed/medias/t4e60u2uct/swatch\" style=\"filter:blur(5px);height:100%;object-fit:contain;width:100%;\" alt=\"\" aria-hidden=\"true\" onload=\"this.parentNode.style.opacity=1;\"/>                                                             </div>                                                         </div>                                                     </div>', '<script src=\"https://fast.wistia.com/embed/medias/t4e60u2uct.jsonp\" async></script>                                                 <script src=\"https://fast.wistia.com/assets/external/E-v1.js\" async></script>                                                 <div class=\"wistia_responsive_padding\" style=\"padding:177.78% 0 0 0;position:relative;\">                                                     <div class=\"wistia_responsive_wrapper\" style=\"height:100%;left:0;position:absolute;top:0;width:100%;\">                                                         <div class=\"wistia_embed wistia_async_t4e60u2uct seo=true videoFoam=true\" style=\"height:100%;position:relative;width:100%\">                                                             <div class=\"wistia_swatch\" style=\"height:100%;left:0;opacity:0;overflow:hidden;position:absolute;top:0;transition:opacity 200ms;width:100%;\">                                                                 <img src=\"https://fast.wistia.com/embed/medias/t4e60u2uct/swatch\" style=\"filter:blur(5px);height:100%;object-fit:contain;width:100%;\" alt=\"\" aria-hidden=\"true\" onload=\"this.parentNode.style.opacity=1;\"/>                                                             </div>                                                         </div>                                                     </div>', '<script src=\"https://fast.wistia.com/embed/medias/t4e60u2uct.jsonp\" async></script>                                                 <script src=\"https://fast.wistia.com/assets/external/E-v1.js\" async></script>                                                 <div class=\"wistia_responsive_padding\" style=\"padding:177.78% 0 0 0;position:relative;\">                                                     <div class=\"wistia_responsive_wrapper\" style=\"height:100%;left:0;position:absolute;top:0;width:100%;\">                                                         <div class=\"wistia_embed wistia_async_t4e60u2uct seo=true videoFoam=true\" style=\"height:100%;position:relative;width:100%\">                                                             <div class=\"wistia_swatch\" style=\"height:100%;left:0;opacity:0;overflow:hidden;position:absolute;top:0;transition:opacity 200ms;width:100%;\">                                                                 <img src=\"https://fast.wistia.com/embed/medias/t4e60u2uct/swatch\" style=\"filter:blur(5px);height:100%;object-fit:contain;width:100%;\" alt=\"\" aria-hidden=\"true\" onload=\"this.parentNode.style.opacity=1;\"/>                                                             </div>                                                         </div>                                                     </div>', '<script src=\"https://fast.wistia.com/embed/medias/t4e60u2uct.jsonp\" async></script>                                                 <script src=\"https://fast.wistia.com/assets/external/E-v1.js\" async></script>                                                 <div class=\"wistia_responsive_padding\" style=\"padding:177.78% 0 0 0;position:relative;\">                                                     <div class=\"wistia_responsive_wrapper\" style=\"height:100%;left:0;position:absolute;top:0;width:100%;\">                                                         <div class=\"wistia_embed wistia_async_t4e60u2uct seo=true videoFoam=true\" style=\"height:100%;position:relative;width:100%\">                                                             <div class=\"wistia_swatch\" style=\"height:100%;left:0;opacity:0;overflow:hidden;position:absolute;top:0;transition:opacity 200ms;width:100%;\">                                                                 <img src=\"https://fast.wistia.com/embed/medias/t4e60u2uct/swatch\" style=\"filter:blur(5px);height:100%;object-fit:contain;width:100%;\" alt=\"\" aria-hidden=\"true\" onload=\"this.parentNode.style.opacity=1;\"/>                                                             </div>                                                         </div>                                                     </div>', '1million+ veiws', '1million+ veiws', '11millio+ veiw', '10million+ veiws', '2024-05-09 10:55:33');

-- --------------------------------------------------------

--
-- Table structure for table `testimony1`
--

CREATE TABLE `testimony1` (
  `id` int(11) NOT NULL,
  `message` varchar(300) NOT NULL,
  `name` varchar(150) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testimony1`
--

INSERT INTO `testimony1` (`id`, `message`, `name`, `ufile`, `updated_at`) VALUES
(12, 'sde', 'Praful Yadav', 'https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg', '2024-05-07 12:30:22'),
(13, 'kuch bhi', 'udhaar singh', 'https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg', '2024-05-07 12:30:37'),
(14, 'kuch bhi', 'kuch bhi', 'https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg', '2024-05-07 12:30:47'),
(15, 'hi hello', 'Praful Yadav', 'https://avatars.githubusercontent.com/u/88019337?v=4', '2024-05-08 13:45:13');

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--

CREATE TABLE `tools` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `ufile` varchar(1000) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tools`
--

INSERT INTO `tools` (`id`, `name`, `ufile`, `updated_at`) VALUES
(1, 'Qlik', '8435Qlik_Logo.svg.png', '2023-11-24 21:27:14');

-- --------------------------------------------------------

--
-- Table structure for table `why_us`
--

CREATE TABLE `why_us` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `detail` varchar(500) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `why_us`
--

INSERT INTO `why_us` (`id`, `title`, `detail`, `updated_on`) VALUES
(3, 'Keyword ranking', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur provident unde ex eligendi magni sit impedit iusto, sed ad fuga minima, dignissimos ducimus autem molestias, nostrum nesciunt enim? Ea, non hic voluptates dolorum impedit eveniet dolorem temporibus illo incidunt quis minima facere doloribus sit maiores, blanditiis labore quasi, accusantium quaerat!', '2022-07-17 18:43:07'),
(4, 'Social media', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur provident unde ex eligendi magni sit impedit iusto, sed ad fuga minima, dignissimos ducimus autem molestias, nostrum nesciunt enim? Ea, non hic voluptates dolorum impedit eveniet dolorem temporibus illo incidunt quis minima facere doloribus sit maiores, blanditiis labore quasi, accusantium quaerat!', '2022-07-17 18:44:19'),
(5, 'trend design', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur provident unde ex eligendi magni sit impedit iusto, sed ad fuga minima, dignissimos ducimus autem molestias, nostrum nesciunt enim? Ea, non hic voluptates dolorum impedit eveniet dolorem temporibus illo incidunt quis minima facere doloribus sit maiores, blanditiis labore quasi, accusantium quaerat!', '2022-07-17 18:44:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aboutstatic`
--
ALTER TABLE `aboutstatic`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog1`
--
ALTER TABLE `blog1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogd`
--
ALTER TABLE `blogd`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dteam`
--
ALTER TABLE `dteam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `frontpage_banner_service`
--
ALTER TABLE `frontpage_banner_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logo`
--
ALTER TABLE `logo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nstatic`
--
ALTER TABLE `nstatic`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scnt`
--
ALTER TABLE `scnt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `section_title`
--
ALTER TABLE `section_title`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_page`
--
ALTER TABLE `service_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `siteconfig`
--
ALTER TABLE `siteconfig`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sitecontact`
--
ALTER TABLE `sitecontact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social`
--
ALTER TABLE `social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sol`
--
ALTER TABLE `sol`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sol1`
--
ALTER TABLE `sol1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `static`
--
ALTER TABLE `static`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `techbanner`
--
ALTER TABLE `techbanner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `techpage`
--
ALTER TABLE `techpage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimony1`
--
ALTER TABLE `testimony1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `why_us`
--
ALTER TABLE `why_us`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aboutstatic`
--
ALTER TABLE `aboutstatic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `blog1`
--
ALTER TABLE `blog1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `blogd`
--
ALTER TABLE `blogd`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dteam`
--
ALTER TABLE `dteam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `frontpage_banner_service`
--
ALTER TABLE `frontpage_banner_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `logo`
--
ALTER TABLE `logo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `nstatic`
--
ALTER TABLE `nstatic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `scnt`
--
ALTER TABLE `scnt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `section_title`
--
ALTER TABLE `section_title`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `service_page`
--
ALTER TABLE `service_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sitecontact`
--
ALTER TABLE `sitecontact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `social`
--
ALTER TABLE `social`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sol`
--
ALTER TABLE `sol`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sol1`
--
ALTER TABLE `sol1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `static`
--
ALTER TABLE `static`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `techbanner`
--
ALTER TABLE `techbanner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `techpage`
--
ALTER TABLE `techpage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `testimony1`
--
ALTER TABLE `testimony1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `why_us`
--
ALTER TABLE `why_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
