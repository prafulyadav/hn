<?php
$con = new mysqli("localhost", "root", "", "digitus");
if ($con->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}


?>

<!DOCTYPE html>
<html
data-wf-domain="Dynamicframes.com"
data-wf-page="65c4bb9b7709fc3e7738c8fb"
data-wf-site="652427491a917cefc5a160de" 
lang="en"
>
<head>

  
    <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
    <link
      href="./index.css"
      rel="stylesheet"
      type="text/css"
    />

    <!-- <link
      href="https://assets-global.website-files.com/652427491a917cefc5a160de/css/visualviewmedia.webflow.28de6f61b.css"
      rel="stylesheet"
      type="text/css"
    /> -->

    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link
      href="https://fonts.gstatic.com"
      rel="preconnect"
      crossorigin="anonymous"
    />
    <script
      src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"
      type="text/javascript"
    ></script>
    <script type="text/javascript">
      WebFont.load({
        google: {
          families: [
            "Poppins:300,300italic,regular,italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic",
          ],
        },
      });
    </script>
    <script type="text/javascript">
      !(function (o, c) {
        var n = c.documentElement,
          t = " w-mod-";
        (n.className += t + "js"),
          ("ontouchstart" in o ||
            (o.DocumentTouch && c instanceof DocumentTouch)) &&
            (n.className += t + "touch");
      })(window, document);
    </script>
    <link
      href="./Dynamic (1).png"
      rel="shortcut icon"
      type="image/x-icon"
    />
    <link
      href="./Dynamic (1).png"
      rel="apple-touch-icon"
    />
  </head>
  <body class="body-short-form">
    <div class="page-wrapper">
      <section class="sticky-nav">
        <div class="padding-global">
          <div class="container-small nav">
            <div class="sticky-nav-element">
              <div class="message-wrapper">
               
              <?php
					 $query="SELECT * FROM sitecontact where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{
	$phone1="$row[phone1]";
	$phone2="$row[phone2]";
    $email1="$row[email1]";
  $insta="$row[insta]";
  $facebook="$row[facebook]";
  $twitter="$row[twitter]";


  print"
  <a href='$insta'>
    <img  src='https://img.icons8.com/3d-fluency/94/instagram-new.png' alt='instagram-new' class='nav-icon'/> </a>
</div>


<div class='links-wrapper'>
    <a id='nav_hov' href='#portfolio' class='sticky-nav-link'>Results</a
    ><a id='nav_hov' href='#process' class='sticky-nav-link'>Achivements</a
    ><a id='nav_hov' href='#reviews' class='sticky-nav-link hide-mobile-landscape'>Reviews</a>
    <a id='nav_hov' href='#pricing' class='sticky-nav-link'>Pricing</a>
</div>
<div class='message-wrapper'>
    <a href='tel:$phone1'><img  src='https://img.icons8.com/3d-fluency/94/phone-disconnected.png' alt='phone-disconnected' class='nav-icon'/>
    </a>
 
</div>

  
  
  ";
}
  ?>
                
              </div>
            </div>
          </div>
        </div>
      </section>
      <div
        data-animation="default"
        data-collapse="medium"
        data-duration="400"
        data-easing="ease"
        data-easing2="ease"
        role="banner"
        class="navbar w-nav"
      >
        <div class="padding-global">
          <div class="navigation-wrapper">
            <div class="nav_text-wrapper hide-tablet hide">
              <div class="text-size-small">
                <!-- Based in Pune, India.<br />Creating for Brands across the world -->
              </div>
            </div>
            <!-- <a href="#" class="brand w-nav-brand"
              ><img
                src="https://assets-global.website-files.com/654100002a3530ee45b2cf03/65463e8bc360222e793ff4c6_logo%20one.png"
                loading="lazy"
                width="60"
                alt=""
                class="logo"
            /></a> -->
            <!-- <nav role="navigation" class="nav-items hide w-nav-menu">
              <a href="#process" class="nav-link-3 w-nav-link">Services</a
              ><a href="#portfolio" class="nav-link-3 w-nav-link">Work</a
              ><a href="#" class="nav-link-3 w-nav-link">Contact</a>
            </nav> -->
          </div>
        </div>
      </div>
      <main class="main-wrapper">
     
        <section
          class="section_home-hero padding-section-large top-4rem on-shortform"
        >
          <div class="padding-global">
            <div class="container-large">
              <div class="hero_heading-content text-align-center">
                <img id="gtm" src="./Dynamic (1).png" alt="">
                <div class="heading-gifs-wrapper">
             
                
                
               


                  <?php
					 $query="SELECT * FROM static where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{
	$stitle="$row[stitle]";
	$stext="$row[stext]";
  $stext2="$row[stext2]";
  print("

  


<h1
  data-w-id='6839fb8f-b6e3-1c4e-caef-af10561309f6'
  class='heading-nohemi'
>
  
</h1>

<h1 class='heading-nohemi'> $stitle</h1>
</div>
<div
  data-w-id='52f86419-b5ba-8d03-9f24-fd002e3ed08f'
  class='div-block-9'
>

  <h1 class='heading-nohemi'></h1>
  <div class='bg-white on-shortform'>
    <h1 class='heading-nohemi'>$stext2</h1>
   
  </div>
  
</div>
<div class='padding-tiny'>


</div>
<div class='padding-medium'>


</div>

<div class='home_hero-content-bottom'>
  <p
    data-w-id='6839fb8f-b6e3-1c4e-caef-af10561309fe'
    class='max-width-48rem'
  >
  $stext
  </p>
  <br>
</div>


");
}
?>
  <!-- <div class="absolute inset-0 flex items-center justify-center transition-all sm:top-4 md:top-40 lg:top-56"
            > -->
              <!-- <video
                muted=""
                autoplay=""
                loop=""
                playsinline=""
                class="mx-auto mt-[-30vh] scale-[2] md:scale-125 lg:mt-[-15vh] xl:mt-[-20vh]"
              >
                <source
                  src="https://assets.mix.com/static/onboarding/intro_desktop.webm"
                  type="video/webm"
                />
                <source
                  src="https://assets.mix.com/static/onboarding/intro_desktop.mp4"
                  type="video/mp4"
                />
              </video> -->

            <!-- </div> -->





                  <div
                    data-w-id="4027e7e1-f3af-3629-066b-2e6cdf6097f7"
                    class="hero_buttons-wrapper on-shortform"
                  >
                    <div class="button-container">
                      <a href="#" class="button-primary w-inline-block"
                        ><div class="dot"></div>
                        <div>Get Started</div>
                        <img
                          src="https://assets-global.website-files.com/652427491a917cefc5a160de/654b104f56d048e2c76a8261_arrow-black.svg"
                          loading="lazy"
                          alt=""
                          class="arrow-button"
                      /></a>
                      <div class="button-shadow"></div>
                    </div>

                    <div class="button-container">
                      <a href="#" class="button-primary w-inline-block"
                        ><div class="dot"></div>
                        <div>See how we do it</div>
                        <img
                          src="https://assets-global.website-files.com/652427491a917cefc5a160de/654b104f56d048e2c76a8261_arrow-black.svg"
                          loading="lazy"
                          alt=""
                          class="arrow-button"
                      /></a>
                      <div class="button-shadow"></div>
                    </div>
                    <!-- <a href="#" class="cta-text-link"></a> -->
                  </div>
                </div>
              </div>
            </div>
          </div>
          <img
            src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c4d18fb553707811ce599a_Frame%204.svg"
            loading="lazy"
            data-w-id="c9c12ede-870b-99b1-50c0-41bc044cd835"
            alt=""
            class="hero-icon-rocket"
          /><img
            src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c4d18fde1e3dcdf2ea3fe7_Video.svg"
            loading="lazy"
            data-w-id="c5ff0734-7cbe-8507-ef55-3836e89abbb5"
            alt=""
            class="hero-icon-camera"
          /><img
            src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c4d18f2a1da604e029d8e6_explosive.svg"
            loading="lazy"
            data-w-id="e83d9c75-5ace-5319-3655-15ba065e46c8"
            alt=""
            class="hero-icon-fire"
          /><img
            src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c4d190a6488ef3723e4853_Frame%203.svg"
            loading="lazy"
            data-w-id="2a8a4698-a0ce-9b3d-48fc-737b541c3b0d"
            alt=""
            class="hero-icon-youtube"
          />
        </section>
        
          
        <section
          id="results"
          class="section_home-numbers padding-section-large"
        >
          <div class="padding-global">
            <div class="container-large">
              <div class="home_numbers-banner-wrapper">
                <div class="home_numbers-banner">
                  <h2 class="text-align-center heading-nohemi">Our Impact</h2>
                  <div class="results_scroll-container hide">
                    <div class="scroll-element"><h2>Our Impact</h2></div>
                    <div class="scroll-element"><h2>Our Impact</h2></div>
                  </div>
                  <div class="padding-medium"></div>
                  <div class="w-layout-grid home_results-grid on-shortform">
                    <div
                      id="w-node-_2a1e3b6f-5df3-6024-9d8b-5ad60a8f8d0d-7738c8fb"
                      class="results_card"
                    >



                    <?php
					 $query="SELECT * FROM nstatic where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{
	$stitle="$row[stitle]";
	$stext="$row[stext]";
  $stext2="$row[stext2]";
  
  print("

  <div class='results-numbers small'>
  <span class=''>$stitle</span>+
</div>
<div class='padding-xsmall'></div>
<div>Videos Published</div>
</div>
<div class='line'></div>
<div id='w-node-a57d5299-6423-e482-43f7-409caf869335-7738c8fb' class='results_card centre'>
  <div class='results-numbers small'>
      <span class=''>$stext2</span>+
    
  </div>
  <div class='padding-xsmall'></div>
  <div>Subscribers Gained</div>
</div>
<div class='line'></div>
<div id='w-node-_47c81152-2cc3-1dbe-605d-a5248897c34f-7738c8fb' class='results_card'>
  <div class='results-numbers small'>
      <span class=''>$stext</span>+
  </div>




");
}


  ?>



                      <div class="padding-xsmall"></div>
                      <div class="text-size-medium">Organic Views</div>
                    </div>
                  </div>
                  <div class="padding-small"></div>
                </div>
                <div class="home_banner-bakcground"></div>
              </div>
            </div>
          </div>
        </section>
       
        <section
          id="portfolio"
          data-w-id="670b74c3-4322-5f29-fa39-aea94a0d1369"
          class="section_home-portfolio padding-section-medium"
        >
          <div class="padding-global">
            <div class="container-large">
              <div
                id="w-node-_866d0130-6b4e-4c69-d58a-f00f27eaed16-7738c8fb"
                class="portfolio-header on0short-form"
              >
                <div
                  id="w-node-ad11035a-aa06-8171-b280-5270a62bad27-7738c8fb"
                  class="h2-wrapper on_portfolio on-shortfrom"
                >
                  <h2 class="h2-line-one heading-nohemi">View</h2>
                  <div class="heading-gifs-wrapper">
                    
                    <h2 class="h2-line-two heading-nohemi">our</h2>
                  </div>
                  <div class="h2-underline-wrapper">
                    <h2 class="h2-line-three heading-nohemi">
                            Results
                    </h2>
                    <img
                      src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc0945adeb6ffc62b37_Frame-1.svg"
                      loading="lazy"
                      width="239"
                      alt=""
                      class="element_underline short"
                    />
                  </div>
                  <img
                    src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc3015470c88712ba8f_Heart.svg"
                    loading="lazy"
                    width="33"
                    alt=""
                    class="element_hearts"
                  /><img
                    src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc2656dfadeef9e00b7_Sketch-annotation-element-brush-pen-icon-crown.svg"
                    loading="lazy"
                    width="74"
                    alt=""
                    class="element-crown"
                  />
                </div>
              </div>
              
              <div class="padding-large"></div>
              <div class="w-layout-grid portfolio_wrapper on-shortform">
                <div
                  id="w-node-_9e1bef26-03ac-44c0-3697-3f715c080fb5-7738c8fb"
                  data-w-id="9e1bef26-03ac-44c0-3697-3f715c080fb5"
                >
                  
                
                <?php
					 $query="SELECT * FROM techpage where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{
	$stitle="$row[stitle]";
	$stext="$row[stext]";
    $img="$row[img]";
    $title1="$row[title1]";
    $text1="$row[text1]";
    $client1="$row[client1]";
    $project1="$row[project1]";
    $year1="$row[year1]";
  print("
  <div id='w-node-df24fde1-c6c9-a74a-51c0-e36f83a26c13-7738c8fb' data-w-id='df24fde1-c6c9-a74a-51c0-e36f83a26c13'>
  
  <div class='moble-design top-left'>
  <div class='div-block'>
    <div class='w-embed w-script'>
    $stitle
    </div>
  </div>
</div>
<div class='creator-info'>$text1</div>
</div>
</div>
</div>



<div id='w-node-_6758ed85-23fd-38b6-785b-434532441e17-7738c8fb' data-w-id='6758ed85-23fd-38b6-785b-434532441e17'>
  <div class='moble-design top-right'>
    <div class='div-block'>
      <div class='w-embed w-script'>
      $stext
      </div>
    </div>
  </div>
  <div class='creator-info'>$client1</div>
</div>
</div>


  <div id='w-node-b781291c-51c4-d8e5-47c6-c6477913bdc5-7738c8fb'
                  data-w-id='b781291c-51c4-d8e5-47c6-c6477913bdc5'
                >
                <div class='moble-design bottom-left'>
    <div class='div-block'>
      <div class='w-embed w-script'>
      $img
      </div>
      
    </div>
  </div>
  <div class='creator-info'>$project1</div>
  </div>
  </div>
  

 

  

  <div
                  id='w-node-df24fde1-c6c9-a74a-51c0-e36f83a26c13-7738c8fb'
                  data-w-id='df24fde1-c6c9-a74a-51c0-e36f83a26c13'
                >

<div class='moble-design bottom-right'>
    <div class='div-block'>
      <div class='w-embed w-script'>
      $title1
      </div>
      
    </div>
  </div>
  <div class='creator-info'>$year1</div>
  </div>
  </div>
  
  


























");








}
?>
                
                
            
        </section>
        <section
          id="process"
          data-w-id="872f3b39-6a6d-172b-d835-a49053e641fc"
          class="section_home-process padding-section-xl is-white on-short-form"
        >
          <div class="padding-global">
            <div class="container-large">
              <div class="process_contents on-shortfrom">
                <div class="process_content-left">
                  <div class="sticky-process-contaner">
                    <div class="h2-wrapper on-process width-100">
                      <h2 class="h2-line-one heading-nohemi">Achived Big Milestones Across the Ocean</h2>
                      <h2 class="h2-line-two heading-nohemi"></h2>
                      <div class="h2-underline-wrapper on-shortfrom">
                        <h2 class="h2-line-three heading-nohemi"></h2>
                        
                        <h2 class="h2-line-three heading-nohemi"></h2>
                        <img
                          src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc0945adeb6ffc62b37_Frame-1.svg"
                          loading="lazy"
                          width="271"
                          alt=""
                          class="element_underline-process on-shortform"
                        />
                      </div>
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc3015470c88712ba8f_Heart.svg"
                        loading="lazy"
                        width="33"
                        alt=""
                        class="element_hearts-copy on-shortform"
                      /><img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc0ab58e12a958f343a_Frame-2.svg"
                        loading="lazy"
                        width="53"
                        alt=""
                        class="element_paperplane"
                      />
                    </div>
                    <div class="button-container">
                      <a href="#" class="button-primary w-inline-block"
                        ><div class="dot"></div>
                        <div>Get Started</div>
                        <img
                          src="https://assets-global.website-files.com/652427491a917cefc5a160de/654b104f56d048e2c76a8261_arrow-black.svg"
                          loading="lazy"
                          alt=""
                          class="arrow-button"
                      /></a>
                      <div class="button-shadow"></div>
                    </div>
                  </div>
                </div>
                <div class="timeline-wrapper">
                  <div class="timeline-bottom"></div>
                  <div class="circles-wrapper">
                    <img
                      src="./pngaaa.com-7386622.png"
                      loading="lazy"
                      alt=""
                      class="timeline-circle"
                    /><img
                      src="./pngaaa.com-7386622.png"
                      loading="lazy"
                      alt=""
                      class="timeline-circle"
                    /><img
                      src="./pngaaa.com-7386622.png"
                      loading="lazy"
                      alt=""
                      class="timeline-circle"
                    /><img
                      src="./pngaaa.com-7386622.png"
                      loading="lazy"
                      alt=""
                      class="timeline-circle"
                    /><img
                      src="./pngaaa.com-7386622.png"
                      loading=""
                      alt=""
                      class="timeline-circle"
                    />
                  </div>
                  <div class="timeline-mask is-grey"></div>
                </div>

                <style>
                  #wt{
color: antiquewhite;
                  }
                </style>
                <div class="process_content-right">
                  <!-- <h1 id="wt">hii</h1> -->
                  <!-- <img src="./pngaaa.com-5234208.png" alt="" > -->
                  <img src="./pngaaa.com-452517.png" alt="" >
                </div>
              
              </div>
            </div>
          </div>
        </section>
        <section
          id="reviews"
          class="section_home-testimonials padding-section-large"
        >
          <div class="home_testimonial-contents">
            <div class="padding-global">
              <div class="h2-wrapper">
                <h2 class="h2-line-one heading-nohemi">Reviews</h2>
                <div class="heading-gifs-wrapper">
                  <h2 class="h2-line-two heading-nohemi">Fro</h2>
                  
                  <h2 class="h2-line-two heading-nohemi">m</h2>
                </div>
                <div class="h2-underline-wrapper">
                  <h2 class="h2-line-three heading-nohemi">    Our Clients</h2>
                  <img
                    src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc07aaa6e39df5225c8_Frame.svg"
                    loading="lazy"
                    width="365"
                    alt=""
                    class="element_underline-main on-testimonials"
                  />
                </div>
                <img
                  src="https://assets-global.website-files.com/652427491a917cefc5a160de/65845672fe2c7d9980c15a9e_spikes.svg"
                  loading="lazy"
                  alt=""
                  class="spikes"
                /><img
                  src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc0dbb6f549d6f2d25a_Sketch-annotation-element-brush-pen-icon-highfive.svg"
                  loading="lazy"
                  alt=""
                  class="element_arrow-down"
                /><img
                  src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc08ef410da6e536afc_Sketch-annotation-element-brush-pen-illustrations-megaphone.svg"
                  loading="lazy"
                  width="104"
                  alt=""
                  class="element_megaphone"
                />
              </div>
            </div>
            <div class="padding-medium"></div>

            <div id="videos">
              <div class="inner">
                <div class="video-carousel-root">
                  <div class="video-carousel-viewport">
                    <div class="video-carousel-slider clearfix" style="left: 0px;">
            
                      
                      
            <!--start of additional video-->
                      <!-- <div id="video_desktop_8_GL" class="level1" data-vimeo-id="181712424">
                        <div class="panel">
                          <div class="poster">
                            
                          <iframe src="https://player.vimeo.com/video/886428353?h=072ed846d1&autoplay=1&loop=1&background=1" style="top:0;left:0;width:100%;height:100%;" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen>
                            </iframe>
                            
                            <div class="buttonme">a</div>
                          </div>
                        </div>
                     
                      </div> -->
                      <!--End of additional-->

                      <?php
				   $q="SELECT * FROM  service ORDER BY id DESC";


 $r123 = mysqli_query($con,$q);

while($ro = mysqli_fetch_array($r123))
{

	$id="$ro[id]";
	$service_title="$ro[service_title]";


  print "

  <div id='video_desktop_8_GL' class='level1' data-vimeo-id='181712424'>
  <div class='panel'>
    <div class='poster'>
    $service_title
      <div class='buttonme'></div>
    </div>
  </div>
  <!-- <p>Never experience an outage again</p> -->
</div>

  
  ";
  
  
  
  }?>
                     
                    </div>
                  </div>
                  <!-- <div class="video-carousel-text" style="display: none;">Support your whole home</div> -->
               
                  
                  <!-- <svg  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><g data-name="Circle kanan"><circle cx="12" cy="12" r="10" style="fill:#ece4b7"/><path d="M11 16a1 1 0 0 1-.707-1.707L12.586 12l-2.293-2.293a1 1 0 0 1 1.414-1.414l3 3a1 1 0 0 1 0 1.414l-3 3A1 1 0 0 1 11 16z" style="fill:#ff8e31"/></g></svg> -->
                  
                  
                  <img class="video-carousel-button-left " src="left.png" alt="long-arrow-right" alt="chevron-left"/>
                  <img class="video-carousel-button-right" src="right.png" alt="chevron-right"/>
                  <!-- <img class="video-carousel-button-left" src="http://www.installgenerac.com/images/video-carousel/arrow_left.png" alt="video carousel navigate left"> -->
                  <!-- <img class="video-carousel-button-right" src="http://www.installgenerac.com/images/video-carousel/arrow_right.png" alt="video carousel navigate right"> -->
                </div>

                <!-- <img width="64" height="64" src="https://img.icons8.com/flat-round/64/000000/arrow--v1.png" alt="arrow--v1"/> -->
              </div>
            </div>
































            <!-- <div class="testimonial-cards-wrapper">
              <div class="testimonial-scroll-container">
                
                
                <div class="testimonial-scroll infinitescroll">
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM.jpeg"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="  https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM-p-500.jpeg  500w,
                        https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM-p-800.jpeg  800w,
                        https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM.jpeg       1032w
                      
                      "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-blue">
                      <p>
                        “Dynamic Frames is helping me run 5+ YouTube channels
                        successfully, helping me scale my media business with
                        top-notch content for the past 3+ years.”<br /><br /><span
                          class="testimonial-author"
                          >- Lazy Assassin</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO.jpg"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO-p-500.jpg 500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO-p-800.jpg 800w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO.jpg       900w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-green">
                      <p>
                        “They have helped me achieve a consistent 50% MOM growth
                        for my Personal brand. They handle everything from
                        content ideation to uploading, requiring just an hour of
                        my time each week.”<br /><br /><span
                          class="testimonial-author"
                          >- Emeka</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec18a1fb065c3c25ecc793_awesome%20genome.jpg"
                        loading="lazy"
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-pink">
                      <p>
                        “Their editing team is excellent. It&#x27;s great when
                        you have a team that is familiar with trends and is
                        ready to adapt.”<br /><br /><span
                          class="testimonial-author"
                          >- Awesome Genome</span
                        >
                      </p>
                    </div>
                  </div>
                </div>

                <div class="testimonial-scroll infinitescroll">
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM.jpeg"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM-p-500.jpeg  500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM-p-800.jpeg  800w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM.jpeg       1032w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-blue">
                      <p>
                        “Dynamic Frames is helping me run 5+ YouTube channels
                        successfully, helping me scale my media business with
                        top-notch content for the past 3+ years.”<br /><br /><span
                          class="testimonial-author"
                          >- Lazy Assassin</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO.jpg"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO-p-500.jpg 500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO-p-800.jpg 800w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO.jpg       900w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-green">
                      <p>
                        “They have helped me achieve a consistent 50% MOM growth
                        for my Personal brand. They handle everything from
                        content ideation to uploading, requiring just an hour of
                        my time each week.”<br /><br /><span
                          class="testimonial-author"
                          >- Emeka</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec18a1fb065c3c25ecc793_awesome%20genome.jpg"
                        loading="lazy"
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-pink">
                      <p>
                        “Their editing team is excellent. It&#x27;s great when
                        you have a team that is familiar with trends and is
                        ready to adapt.”<br /><br /><span
                          class="testimonial-author"
                          >- Awesome Genome</span
                        >
                      </p>
                    </div>
                  </div>
                </div>
                
                <div class="testimonial-scroll infinitescroll">
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM.jpeg"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM-p-500.jpeg  500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM-p-800.jpeg  800w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec15576cf469713eb5e408_WhatsApp%20Image%202024-03-09%20at%201.19.12%20PM.jpeg       1032w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-blue">
                      <p>
                        “Dynamic Frames is helping me run 5+ YouTube channels
                        successfully, helping me scale my media business with
                        top-notch content for the past 3+ years.”<br /><br /><span
                          class="testimonial-author"
                          >- Lazy Assassin</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO.jpg"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO-p-500.jpg 500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO-p-800.jpg 800w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153448973ba6253732e4_Emeka%20ODO.jpg       900w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-green">
                      <p>
                        “They have helped me achieve a consistent 50% MOM growth
                        for my Personal brand. They handle everything from
                        content ideation to uploading, requiring just an hour of
                        my time each week.”<br /><br /><span
                          class="testimonial-author"
                          >- Emeka</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec18a1fb065c3c25ecc793_awesome%20genome.jpg"
                        loading="lazy"
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-pink">
                      <p>
                        “Their editing team is excellent. It&#x27;s great when
                        you have a team that is familiar with trends and is
                        ready to adapt.”<br /><br /><span
                          class="testimonial-author"
                          >- Awesome Genome</span
                        >
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div class="testimonial-scroll-container">
                <div class="testimonial-scroll infinitescroll bottom">
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec170fe899c865980a1634_Testing%20Academy.png"
                        loading="lazy"
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-green">
                      <p>
                        “Visualviews Media is helping me leverage my YouTube
                        channel to sell courses, and I&#x27;ve seen a 10x
                        increase in revenue using their strategy and management
                        services. Their personal branding and content strategies
                        are game-changing.”<br /><br /><span
                          class="testimonial-author"
                          >- The Testing Academy</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec154a596971e34961f6b2_kenny.png"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec154a596971e34961f6b2_kenny-p-500.png 500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec154a596971e34961f6b2_kenny.png       594w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-pink">
                      <p>
                        “They helped boost my views from 5-6 million to over 25
                        million monthly, helping me attract major sponsors like
                        Samsung. Can&#x27;t thank them enough for the incredible
                        growth!”<br /><br /><span class="testimonial-author"
                          >- Kenny Jo</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude.jpg"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude-p-500.jpg 500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude-p-800.jpg 800w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude.jpg       900w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-blue">
                      <p>
                        “Dynamic Frames&#x27;s content strategy is unmatched.
                        I went from 0-15k+ subscribers on YouTube in just 4
                        months using their strategy.”<br /><br /><span
                          class="testimonial-author"
                          >- The AI Dude</span
                        >
                      </p>
                    </div>
                  </div>
                </div>
                <div class="testimonial-scroll infinitescroll bottom">
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec170fe899c865980a1634_Testing%20Academy.png"
                        loading="lazy"
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-green">
                      <p>
                        “Visualviews Media is helping me leverage my YouTube
                        channel to sell courses, and I&#x27;ve seen a 10x
                        increase in revenue using their strategy and management
                        services. Their personal branding and content strategies
                        are game-changing.”<br /><br /><span
                          class="testimonial-author"
                          >- The Testing Academy</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec154a596971e34961f6b2_kenny.png"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec154a596971e34961f6b2_kenny-p-500.png 500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec154a596971e34961f6b2_kenny.png       594w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-pink">
                      <p>
                        “They helped boost my views from 5-6 million to over 25
                        million monthly, helping me attract major sponsors like
                        Samsung. Can&#x27;t thank them enough for the incredible
                        growth!”<br /><br /><span class="testimonial-author"
                          >- Kenny Jo</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude.jpg"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude-p-500.jpg 500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude-p-800.jpg 800w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude.jpg       900w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-blue">
                      <p>
                        “Dynamic Frames&#x27;s content strategy is unmatched.
                        I went from 0-15k+ subscribers on YouTube in just 4
                        months using their strategy.”<br /><br /><span
                          class="testimonial-author"
                          >- The AI Dude</span
                        >
                      </p>
                    </div>
                  </div>
                </div>
                <div class="testimonial-scroll infinitescroll bottom">
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec170fe899c865980a1634_Testing%20Academy.png"
                        loading="lazy"
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-green">
                      <p>
                        “Visualviews Media is helping me leverage my YouTube
                        channel to sell courses, and I&#x27;ve seen a 10x
                        increase in revenue using their strategy and management
                        services. Their personal branding and content strategies
                        are game-changing.”<br /><br /><span
                          class="testimonial-author"
                          >- The Testing Academy</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec154a596971e34961f6b2_kenny.png"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec154a596971e34961f6b2_kenny-p-500.png 500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec154a596971e34961f6b2_kenny.png       594w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-pink">
                      <p>
                        “They helped boost my views from 5-6 million to over 25
                        million monthly, helping me attract major sponsors like
                        Samsung. Can&#x27;t thank them enough for the incredible
                        growth!”<br /><br /><span class="testimonial-author"
                          >- Kenny Jo</span
                        >
                      </p>
                    </div>
                  </div>
                  <div class="testimonial-card">
                    <div class="testimonial_author_image-wrapper">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude.jpg"
                        loading="lazy"
                        sizes="(max-width: 767px) 100vw, 223.99307250976562px"
                        srcset="
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude-p-500.jpg 500w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude-p-800.jpg 800w,
                          https://assets-global.website-files.com/652427491a917cefc5a160de/65ec153434196b9c90109c22_the%20AI%20dude.jpg       900w
                        "
                        alt=""
                        class="testimonial_author_image"
                      />
                    </div>
                    <div class="testimonial-wrapper color-blue">
                      <p>
                        “Dynamic Frames&#x27;s content strategy is unmatched.
                        I went from 0-15k+ subscribers on YouTube in just 4
                        months using their strategy.”<br /><br /><span
                          class="testimonial-author"
                          >- The AI Dude</span
                        >
                      </p>
                    </div>
                  </div>
                </div> -->
              </div>
            </div>
          </div>
        </section>
        <section class="section_home-case-studies">
          <div class="padding-global">
            <div class="padding-section-large">
              <div class="container-large">
                <div class="h2-wrapper">
                  <h2 class="h2-line-one heading-nohemi">Our</h2>
                  <div class="heading-gifs-wrapper spacious">
                    <h2 class="h2-line-two heading-nohemi">Most</h2>
                    
                  </div>
                  <div class="h2-underline-wrapper">
                    <h2 class="h2-line-three heading-nohemi">  Talented Team</h2>
                    <img
                      src="https://assets-global.website-files.com/652427491a917cefc5a160de/6566b7d78e59d96d37e97c37_heading-underline.svg"
                      loading="lazy"
                      width="365"
                      alt=""
                      class="element_underline-main on-testimonials"
                    />
                  </div>
                  <img
                    src="https://assets-global.website-files.com/652427491a917cefc5a160de/659111c60aed1426bf11764f_Abstract%20Scratch%20Dash%20Line%20Rain.svg"
                    loading="lazy"
                    alt=""
                    class="bullets"
                  /><img
                    src="https://assets-global.website-files.com/652427491a917cefc5a160de/659111c7015470c8871407e3_Sketch-annotation-element-brush-pen-icon-sticky-note.svg"
                    loading="lazy"
                    width="104"
                    alt=""
                    class="note"
                  /><img
                    src="https://assets-global.website-files.com/652427491a917cefc5a160de/659111c6ceefdb2a6e89ac38_Sketch-annotation-element-brush-pen-illustrations-achievement-cup.svg"
                    loading="lazy"
                    width="104"
                    alt=""
                    class="trophy"
                  />
                </div>
                <div class="padding-medium"></div>
                <div class="case-studies-wrapper">
                  <div>
                    <!-- <div class="w-dyn-list">
                      <div role="list" class="w-dyn-items">
                        <div role="listitem" class="w-dyn-item">
                          <a
                            href="/case-study/kenny-jo"
                            class="div-block-6 w-inline-block"
                            ><div class="cs-title">Kenny Jo</div>
                            <div class="cs-date">Multiple Sponsorships</div>
                            <div>January 26, 2024</div></a
                          >
                        </div>
                        <div role="listitem" class="w-dyn-item">
                          <a
                            href="/case-study/the-testing-academy"
                            class="div-block-6 w-inline-block"
                            ><div class="cs-title">The Testing Academy</div>
                            <div class="cs-date">Multiple Viral videos</div>
                            <div>January 28, 2024</div></a
                          >
                        </div>
                      </div>
                    </div> -->


                    <div class="marquee-wrapper" style="user-select: none;">
  <div class="marquee-content scrollingX">
   
  
  <!-- <div class="card-testimonial">
      <article>
        <picture>
          <source media="(min-width: 768px)" srcset="https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg">
          <img src="https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg" alt="">
        </picture>
        <h4>Title 1</h4>
        <article class="short-description">
          <p>Description 1</p>
        </article>
      </article>
    </div> -->




    <?php
                                    $q = "SELECT * FROM  testimony1 ORDER BY id DESC";


                                    $r123 = mysqli_query($con, $q);

                                    while ($ro = mysqli_fetch_array($r123)) {

                                        $id = "$ro[id]";
                                        $name = "$ro[name]";
                                        $message="$ro[message]";
                                        $ufile = "$ro[ufile]";


                                        print "

                                        <div class='card-testimonial'>
      <article>
        <picture>
          <source media='(min-width: 768px)' srcset='$ufile'>
          <img src='$ufile' alt=''>
        </picture>
        <h4> $name</h4>
        <article class='short-description'>
          <p>$message</p>
        </article>
      </article>
</div>

                                        
                                     
                                        "; } ?>



<!-- https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg -->








   



    <!-- <div class="card-testimonial">
      <article>
        <picture>
          <source media="(min-width: 768px)" srcset="https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg">
          <img src="https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg" alt="">
        </picture>
        <h4>Title 1</h4>
        <article class="short-description">
          <p>Description 1</p>
        </article>
      </article>
    </div>


    <div class="card-testimonial">
      <article>
        <picture>
          <source media="(min-width: 768px)" srcset="https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg">
          <img src="https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg" alt="">
        </picture>
        <h4>Title 1</h4>
        <article class="short-description">
          <p>Description 1</p>
        </article>
      </article>
    </div>


    <div class="card-testimonial">
      <article>
        <picture>
          <source media="(min-width: 768px)" srcset="https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg">
          <img src="https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg" alt="">
        </picture>
        <h4>Title 1</h4>
        <article class="short-description">
          <p>Description 1</p>
        </article>
      </article>
    </div>
   
   
    <div class="card-testimonial">
      <article>
        <picture>
          <source media="(min-width: 768px)" srcset="https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg">
          <img src="https://assets-global.website-files.com/65f330899cd403fd460a9b47/65f92dabc7cfd863ae39dd73_2.jpg" alt="">
        </picture>
        <h4>Title 2</h4>
        <article class="short-description">
          <p>Description 2</p>
        </article>
      </article>
    </div> -->



  
  </div>
</div>






                   




          
 



                    
	

  










                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>




















        <section
          id="pricing"
          class="section_home-pricing padding-section-large on-shortform"
        >
          <div class="padding-global">
            <div class="container-large">
              <div class="h2-wrapper">
                <h2 class="h2-line-one heading-nohemi">Start Your</h2>
                <div class="heading-gifs-wrapper">
                  <!-- <h2 class="h2-line-two heading-nohemi">Y</h2> -->
                 
                  <!-- <h2 class="h2-line-two heading-nohemi">ur</h2> -->
                </div>
                <div class="h2-underline-wrapper">
                  <h2 class="h2-line-one heading-nohemi">                     Journey</h2>
                  <img
                    src="https://assets-global.website-files.com/652427491a917cefc5a160de/6566b7d78e59d96d37e97c37_heading-underline.svg"
                    loading="lazy"
                    width="401"
                    alt=""
                    class="element_underline-main on-pricing on-shortfrom"
                  />
                </div>
                <img
                  src="https://assets-global.website-files.com/652427491a917cefc5a160de/659111777aaa6e39df5319ac_Arrow%20Ribbon%20Back%20Zigzag.svg"
                  loading="lazy"
                  alt=""
                  class="downfall"
                /><img
                  src="https://assets-global.website-files.com/652427491a917cefc5a160de/659111774f03c0b3fb60823e_Highlight_10.svg"
                  loading="lazy"
                  alt=""
                  class="clound-highlight"
                /><img
                  src="https://assets-global.website-files.com/652427491a917cefc5a160de/65911177fb84bc3e3dd57df1_Abstract%20Half%20Oval.svg"
                  loading="lazy"
                  alt=""
                  class="bubble-half"
                />
              </div>
              <div class="padding-large"></div>
              <div class="w-layout-grid pricing-grid on-short-from">
                <div
                  id="w-node-c276093e-0760-25b8-8ae3-6e07b327894e-7738c8fb"
                  class="pricing_card on-shortform"
                >
                  <div class="pricing-content-top">

                  <?php
					 $query="SELECT * FROM plans where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{
	$stitle="$row[stitle]";
	$stext="$row[stext]";
    $stext2="$row[stext2]";
	$stext1="$row[stext1]";
    $stext3="$row[stext3]";
    $stext4="$row[stext4]";

print"
<div class='pricing-details'>
  <h3 class='heading_pricing heading-nohemi'>
  $stitle
  </h3>
  <div class='price-tag'>
    $$stext<span class='per-month'>/month</span>
  </div>
</div>

";

}
  ?>







                    <!-- <div class="pricing-details">
                      <h3 class="heading_pricing heading-nohemi">
                        Starter Pack
                      </h3>
                      <div class="price-tag">
                        $1,499<span class="per-month">/month</span>
                      </div>
                    </div> -->




                    <div class="checks_wrapper">
                      <div class="check-item"><div>Plan Includes:</div></div>
                      <div class="check-item">
                        <img
                          src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                          loading="lazy"
                          alt=""
                        />
                        <div>25 Shorts Edit</div>
                      </div>
                      <div class="check-item">
                        <img
                          src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                          loading="lazy"
                          alt=""
                        />
                        <div>Unlimited revisions</div>
                      </div>
                      <div class="check-item">
                        <img
                          src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                          loading="lazy"
                          alt=""
                        />
                        <div>Youtube Uploads only</div>
                      </div>
                      <div class="check-item">
                        <img
                          src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                          loading="lazy"
                          alt=""
                        />
                        <div>Monthly Reporting</div>
                      </div>
                    </div>
                  </div>
                  <a
                    href="link"
                    target="_blank"
                    class="button-pricing on-short-form w-inline-block"
                    ><div class="dot is-white"></div>
                    <div>Start Now</div>
                    <img
                      src="https://assets-global.website-files.com/652427491a917cefc5a160de/6566b35fe14c9488472f9ea4_arrow-white.svg"
                      loading="lazy"
                      alt=""
                  /></a>
                </div>
                <div
                  id="w-node-_2d011a56-58b8-4fd8-c622-e86bc4de5b6b-7738c8fb"
                  class="pricing_card on-shortform primary"
                >


                <?php
					 $query="SELECT * FROM plans where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{
	$stitle="$row[stitle]";
	$stext="$row[stext]";
    $stext2="$row[stext2]";
	$stext1="$row[stext1]";
    $stext3="$row[stext3]";
    $stext4="$row[stext4]";

print"
<div class='pricing-details'>
                    <h3 class='heading_pricing heading-nohemi'>
                    $stext2
                    </h3>
                    <div class='price-tag'>
                      $$stext3<span class='per-month'>/month</span>
                    </div>


";

}
  ?>

                  
                
               



                  </div>
                  <div class="checks_wrapper">
                    <div class="check-item"><div>Plan Includes:</div></div>
                    <div class="check-item">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                        loading="lazy"
                        alt=""
                      />
                      <div>4 Podcast</div>
                    </div>
                    <div class="check-item">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                        loading="lazy"
                        alt=""
                      />
                      <div>Unlimited Shorts</div>
                    </div>
                    <div class="check-item">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                        loading="lazy"
                        alt=""
                      />
                      <div>Unlimited Thumbnails</div>
                    </div>
                    <div class="check-item">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                        loading="lazy"
                        alt=""
                      />
                      <div>Unlimited Revisions</div>
                    </div>
                    <div class="check-item">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                        loading="lazy"
                        alt=""
                      />
                      <div>Distribution across 5 Platforms</div>
                    </div>
                    <div class="check-item">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                        loading="lazy"
                        alt=""
                      />
                      <div>Moneyback Guarantee</div>
                    </div>
                    <div class="check-item">
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                        loading="lazy"
                        alt=""
                      />
                      <div>We help you get guest</div>
                    </div>
                  </div>
                  <a
                    href="link"
                    target="_blank"
                    class="button-pricing main w-inline-block"
                    ><div class="dot"></div>
                    <div>Start Now</div>
                    <img
                      src="https://assets-global.website-files.com/652427491a917cefc5a160de/654b104f56d048e2c76a8261_arrow-black.svg"
                      loading="lazy"
                      alt=""
                  /></a>
                  <div class="text-block">Most Popular</div>
                </div>
                <div
                  id="w-node-f8bb9f43-aa14-79fc-8af2-965019134bff-7738c8fb"
                  class="pricing_card on-shortform"
                >
                  <div class="pricing-content-top">
                    
                  <?php
					 $query="SELECT * FROM plans where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{
	$stitle="$row[stitle]";
	$stext="$row[stext]";
    $stext2="$row[stext2]";
	$stext1="$row[stext1]";
    $stext3="$row[stext3]";
    $stext4="$row[stext4]";

print"
<div class='pricing-details'>
    <h3 class='heading_pricing heading-nohemi'>$stext1</h3>
    <div class='price-tag'>
        $$stext4<span class='per-month'>/month</span>
    </div>



";

}
  ?>
                 



                    </div>
                    <div class="checks_wrapper">
                      <div class="check-item"><div>Plan Includes:</div></div>
                      <div class="check-item">
                        <img
                          src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                          loading="lazy"
                          alt=""
                        />
                        <div>1 Podcast Edit</div>
                      </div>
                      <div class="check-item">
                        <img
                          src="https://assets-global.website-files.com/652427491a917cefc5a160de/65c50e0fdec03d69a202725c_check%20yellow.svg"
                          loading="lazy"
                          alt=""
                        />
                        <div>2 Shorts Edit</div>
                      </div>
                    </div>
                  </div>
                  <a
                    href="link"
                    target="_blank"
                    class="button-pricing on-short-form w-inline-block"
                    ><div class="dot is-white"></div>
                    <div>Start Now</div>
                    <img
                      src="https://assets-global.website-files.com/652427491a917cefc5a160de/6566b35fe14c9488472f9ea4_arrow-white.svg"
                      loading="lazy"
                      alt=""
                  /></a>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section id="cta-section" class="section_home-cta">
          <div class="padding-global">
            <div class="padding-section-large">
              <div class="container-medium">
                <div class="cta-section-component on-shortform">
                  <div class="h2-wrapper wide">
                    <!-- <h2 class="h2-line-one heading-nohemi">Take</h2> -->
                    <div class="heading-gifs-wrapper">
                      <h2 class="h2-line-two heading-nohemi">About</h2>
                      
                      <h2 class="h2-line-two heading-nohemi"></h2>
                    </div>
                    <div class="h2-underline-wrapper">
                      <h2
                        class="h2-line-three heading-nohemi text-align-center"
                      >
                        Us..
                      </h2>
                      <img
                        src="https://assets-global.website-files.com/652427491a917cefc5a160de/6566b7d78e59d96d37e97c37_heading-underline.svg"
                        loading="lazy"
                        width="401"
                        alt=""
                        class="element_underline-main on-cta"
                      />
                    </div>
                    <img
                      src="https://assets-global.website-files.com/652427491a917cefc5a160de/65842513f813409cb6b1bca6_Arrow%203d%20Boomerang.svg"
                      loading="lazy"
                      width="138"
                      alt=""
                      class="arrow-cta"
                    />
                  </div>
                  <div class="padding-medium"></div>
                  <div class="max-width-medium align-center text-align-center">
                  
                  
                  
                  <?php
					 $query="SELECT * FROM sitecontact where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{

	$phone2="$row[phone2]";
   


  print"
  <div>
  $phone2         
                    </div>
  ";
  } ?>
                  
                  


                  </div>
                  <div class="padding-medium"></div>
                  <div class="div-block-3">
                    <img
                      src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc2945adeb6ffc62cca_Sketch-annotation-element-brush-pen-abstract-spring-line-curly-1.svg"
                      loading="lazy"
                      alt=""
                      class="cta-element-bottom"
                    /><img
                      src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fbefb84bc3e3dd440e4_Abstract%20Motion%20Ball%20Line.svg"
                      loading="lazy"
                      alt=""
                      class="cta-element-top"
                    />
                    


                    <?php
					 $query="SELECT * FROM sitecontact where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{

	$phone1="$row[phone1]";
   


  print"
  <a
  href='tel:$phone1'
  target='_blank'
  class='cta-large w-inline-block'
>
  <div>Book a Strategy Call (it’s FREE)</div>
</a>
  ";
  } ?>


                 



                    <div class="cta_large-shadow"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="section_home-faqs">
          <div class="padding-global">
            <div class="padding-section-large">
              <div class="container-medium">
                <div class="h2-wrapper wide">
                  <h2 class="h2-line-one heading-nohemi">Answering</h2>
                  <h2 class="h2-line-two heading-nohemi">Frequent</h2>
                  <div class="h2-underline-wrapper">
                    <h2 class="h2-line-three heading-nohemi text-align-center">
                      Questions
                    </h2>
                    <img
                      src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc0945adeb6ffc62b37_Frame-1.svg"
                      loading="lazy"
                      width="401"
                      alt=""
                      class="element_underline-main on-faqs"
                    />
                  </div>
                  <img
                    src="https://assets-global.website-files.com/652427491a917cefc5a160de/65842e0efa0425e0fef5cc40_Question%20Sign.svg"
                    loading="lazy"
                    width="138"
                    alt=""
                    class="question-mark"
                  /><img
                    src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc15e79882f913c1416_Abstract%20Scratch%203-1.svg"
                    loading="lazy"
                    alt=""
                    class="lines-top"
                  /><img
                    src="https://assets-global.website-files.com/652427491a917cefc5a160de/65910fc009b2abe332afd6c1_Sketch-annotation-element-brush-pen-icon-exclamation-mark.svg"
                    loading="lazy"
                    alt=""
                    class="exclamation"
                  />
                </div>
                <div class="padding-large"></div>
                <div class="faqs-wrapper">
                  <div
                    data-w-id="214d3f7f-ba82-bea0-b61c-121d1df6f092"
                    class="accordion-item---brix tabs-accordion---brix"
                  >
                    <div class="accordion-trigger---brix">
                      <div class="div-block-4">
                        <div class="dot yellow"></div>
                        <div class="accordion-item-title---brix">
                          How is Dynamic Frames different?
                        </div>
                      </div>
                      <div class="open-close-icon-wrapper---brix">
                        <div class="open-close-line---brix"></div>
                        <div
                          style="
                            -webkit-transform: translate3d(0, 0, 0)
                              scale3d(1, 1, 1) rotateX(0) rotateY(0)
                              rotateZ(90deg) skew(0, 0);
                            -moz-transform: translate3d(0, 0, 0)
                              scale3d(1, 1, 1) rotateX(0) rotateY(0)
                              rotateZ(90deg) skew(0, 0);
                            -ms-transform: translate3d(0, 0, 0) scale3d(1, 1, 1)
                              rotateX(0) rotateY(0) rotateZ(90deg) skew(0, 0);
                            transform: translate3d(0, 0, 0) scale3d(1, 1, 1)
                              rotateX(0) rotateY(0) rotateZ(90deg) skew(0, 0);
                          "
                          class="open-close-line---brix second-line---brix"
                        ></div>
                      </div>
                    </div>
                    <div
                      style="
                        height: 0px;
                        -webkit-transform: translate3d(0, 0, 0)
                          scale3d(0.9, 0.9, 1) rotateX(0) rotateY(0) rotateZ(0)
                          skew(0, 0);
                        -moz-transform: translate3d(0, 0, 0)
                          scale3d(0.9, 0.9, 1) rotateX(0) rotateY(0) rotateZ(0)
                          skew(0, 0);
                        -ms-transform: translate3d(0, 0, 0) scale3d(0.9, 0.9, 1)
                          rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                        transform: translate3d(0, 0, 0) scale3d(0.9, 0.9, 1)
                          rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                        opacity: 0;
                      "
                      class="accordion-content---brix"
                    >
                      <p class="accordion-paragraph---brix">
                        Dynamic Frames stands out by offering data-driven
                        content marketing strategies tailored for brands. We
                        focus on collaboration, transparent reporting, and
                        scalable solutions to ensure your brand&#x27;s growth
                        and success.
                      </p>
                    </div>
                  </div>
                  <div
                    data-w-id="fe5619b7-5d93-75c0-b9a3-c8325fcae75a"
                    class="accordion-item---brix tabs-accordion---brix"
                  >
                    <div class="accordion-trigger---brix">
                      <div class="div-block-4">
                        <div class="dot yellow"></div>
                        <div class="accordion-item-title---brix">
                          What Kind of results can I expect?
                        </div>
                      </div>
                      <div class="open-close-icon-wrapper---brix">
                        <div class="open-close-line---brix"></div>
                        <div
                          style="
                            -webkit-transform: translate3d(0, 0, 0)
                              scale3d(1, 1, 1) rotateX(0) rotateY(0)
                              rotateZ(90deg) skew(0, 0);
                            -moz-transform: translate3d(0, 0, 0)
                              scale3d(1, 1, 1) rotateX(0) rotateY(0)
                              rotateZ(90deg) skew(0, 0);
                            -ms-transform: translate3d(0, 0, 0) scale3d(1, 1, 1)
                              rotateX(0) rotateY(0) rotateZ(90deg) skew(0, 0);
                            transform: translate3d(0, 0, 0) scale3d(1, 1, 1)
                              rotateX(0) rotateY(0) rotateZ(90deg) skew(0, 0);
                          "
                          class="open-close-line---brix second-line---brix"
                        ></div>
                      </div>
                    </div>
                    <div
                      style="
                        height: 0px;
                        -webkit-transform: translate3d(0, 0, 0)
                          scale3d(0.9, 0.9, 1) rotateX(0) rotateY(0) rotateZ(0)
                          skew(0, 0);
                        -moz-transform: translate3d(0, 0, 0)
                          scale3d(0.9, 0.9, 1) rotateX(0) rotateY(0) rotateZ(0)
                          skew(0, 0);
                        -ms-transform: translate3d(0, 0, 0) scale3d(0.9, 0.9, 1)
                          rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                        transform: translate3d(0, 0, 0) scale3d(0.9, 0.9, 1)
                          rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                        opacity: 0;
                      "
                      class="accordion-content---brix"
                    >
                      <p class="accordion-paragraph---brix">
                        Keeping our track record in mind we will beat your
                        exisiting results by a huge margin.
                      </p>
                    </div>
                  </div>
                  <div
                    data-w-id="dfe3597e-6227-a302-c31a-0c6dec5dfcc2"
                    class="accordion-item---brix tabs-accordion---brix"
                  >
                    <div class="accordion-trigger---brix">
                      <div class="div-block-4">
                        <div class="dot yellow"></div>
                        <div class="accordion-item-title---brix">
                          How do we communicate?
                        </div>
                      </div>
                      <div class="open-close-icon-wrapper---brix">
                        <div class="open-close-line---brix"></div>
                        <div
                          style="
                            -webkit-transform: translate3d(0, 0, 0)
                              scale3d(1, 1, 1) rotateX(0) rotateY(0)
                              rotateZ(90deg) skew(0, 0);
                            -moz-transform: translate3d(0, 0, 0)
                              scale3d(1, 1, 1) rotateX(0) rotateY(0)
                              rotateZ(90deg) skew(0, 0);
                            -ms-transform: translate3d(0, 0, 0) scale3d(1, 1, 1)
                              rotateX(0) rotateY(0) rotateZ(90deg) skew(0, 0);
                            transform: translate3d(0, 0, 0) scale3d(1, 1, 1)
                              rotateX(0) rotateY(0) rotateZ(90deg) skew(0, 0);
                          "
                          class="open-close-line---brix second-line---brix"
                        ></div>
                      </div>
                    </div>
                    <div
                      style="
                        height: 0px;
                        -webkit-transform: translate3d(0, 0, 0)
                          scale3d(0.9, 0.9, 1) rotateX(0) rotateY(0) rotateZ(0)
                          skew(0, 0);
                        -moz-transform: translate3d(0, 0, 0)
                          scale3d(0.9, 0.9, 1) rotateX(0) rotateY(0) rotateZ(0)
                          skew(0, 0);
                        -ms-transform: translate3d(0, 0, 0) scale3d(0.9, 0.9, 1)
                          rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                        transform: translate3d(0, 0, 0) scale3d(0.9, 0.9, 1)
                          rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                        opacity: 0;
                      "
                      class="accordion-content---brix"
                    >
                      <p class="accordion-paragraph---brix">
                        We do all communication in slack. Our editors and
                        managers are always ready to answer your questions.
                      </p>
                    </div>
                  </div>
                  <div
                    data-w-id="f7df87ab-0066-de4a-a758-ba9b31a63f51"
                    class="accordion-item---brix tabs-accordion---brix"
                  >
                    <div class="accordion-trigger---brix">
                      <div class="div-block-4">
                        <div class="dot yellow"></div>
                        <div class="accordion-item-title---brix">
                          If I cancel, DO I get a refund?
                        </div>
                      </div>
                      <div class="open-close-icon-wrapper---brix">
                        <div class="open-close-line---brix"></div>
                        <div
                          style="
                            -webkit-transform: translate3d(0, 0, 0)
                              scale3d(1, 1, 1) rotateX(0) rotateY(0)
                              rotateZ(90deg) skew(0, 0);
                            -moz-transform: translate3d(0, 0, 0)
                              scale3d(1, 1, 1) rotateX(0) rotateY(0)
                              rotateZ(90deg) skew(0, 0);
                            -ms-transform: translate3d(0, 0, 0) scale3d(1, 1, 1)
                              rotateX(0) rotateY(0) rotateZ(90deg) skew(0, 0);
                            transform: translate3d(0, 0, 0) scale3d(1, 1, 1)
                              rotateX(0) rotateY(0) rotateZ(90deg) skew(0, 0);
                          "
                          class="open-close-line---brix second-line---brix"
                        ></div>
                      </div>
                    </div>
                    <div
                      style="
                        height: 0px;
                        -webkit-transform: translate3d(0, 0, 0)
                          scale3d(0.9, 0.9, 1) rotateX(0) rotateY(0) rotateZ(0)
                          skew(0, 0);
                        -moz-transform: translate3d(0, 0, 0)
                          scale3d(0.9, 0.9, 1) rotateX(0) rotateY(0) rotateZ(0)
                          skew(0, 0);
                        -ms-transform: translate3d(0, 0, 0) scale3d(0.9, 0.9, 1)
                          rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                        transform: translate3d(0, 0, 0) scale3d(0.9, 0.9, 1)
                          rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                        opacity: 0;
                      "
                      class="accordion-content---brix"
                    >
                      <p class="accordion-paragraph---brix">
                        We will not refund for the current month but you can
                        request cancellation before billing of your next month.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer class="section_home-footer">
        <div class="padding-global">
          <div class="padding-section-medium">
            <div class="container-large">
              <div class="footer-content-topo">
                <!-- <div class="div-block-5">
                  <a href="#">About</a><a href="#">Contact</a
                  ><a href="#">Home</a>
                </div> -->
                <div>
                  <!-- <div class="text-size-medium">
                    Keep up with me if you can.
                  Keep up with me if you can.
                  </div> -->
                  <div class="padding-small"></div>
                  <!-- <div class="form-block w-form">
                    <form
                      id="email-form"
                      name="email-form"
                      data-name="Email Form"
                      method="get"
                      class="form"
                      data-wf-page-id="65c4bb9b7709fc3e7738c8fb"
                      data-wf-element-id="33c1532e-e535-de36-154b-a63a24e2a4d7"
                    >
                      <input
                        class="text-field w-input"
                        maxlength="256"
                        name="email-2"
                        data-name="Email 2"
                        placeholder="Enter your Email Address"
                        type="email"
                        id="email-2"
                        required=""
                      /><input
                        type="submit"
                        data-wait="Please wait..."
                        class="submit-button w-button"
                        value="Subscribe"
                      />
                    </form>
                    <div class="w-form-done">
                      <div>Thank you! Your submission has been received!</div>
                    </div>
                    <div class="w-form-fail">
                      <div>
                        Oops! Something went wrong while submitting the form.
                      </div>
                    </div>
                  </div> -->
                </div>
              </div>
              <div class="padding-medium"></div>
              <div class="footer-extras">
                
              
              
              
              
              
              
              
              <div class="div-block-8">
                  <div>
                 
                 
                 <?php
					 $query="SELECT * FROM sitecontact where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{

	$insta="$row[insta]";
  $email1="$row[email1]";
  $facebook="$row[facebook]";
  $twitter="$row[twitter]";
  
   


  print"
  <a
                      href='mailto:$email1'
                      class='text-color-grey w-inline-block'
                      ><div>
                        Email:<strong> $email1</strong>
                      </div></a
                    >
  ";} ?>


                  </div>
                  <div class="sociakl-links--wrapper">
                  <?php
					 $query="SELECT * FROM sitecontact where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{

	$insta="$row[insta]";
  $email1="$row[email1]";
  $facebook="$row[facebook]";
  $twitter="$row[twitter]";
  
   


  print"
  <a href='$insta' target='_blank' class='social-link w-inline-block'><img src='https://assets-global.website-files.com/652427491a917cefc5a160de/658ceff999e5cbfecc39adb6_Instagram.svg' loading='lazy' width='18' alt='' /></a>
  <a href='$facebook' target='_blank' class='social-link w-inline-block'><img src='https://assets-global.website-files.com/652427491a917cefc5a160de/658ceff26b166e0e0a1dce76_ic%20Linkedin.svg' loading='lazy' width='18' alt='' /></a>

  ";} ?>
                    

                   
                  </div>
                </div>
                <div><div>Privacy Policy</div></div>
                <div><div>Terms of Service</div></div>
                <div>

                <?php
					 $query="SELECT * FROM sitecontact where id=1 ";


 $result = mysqli_query($con,$query);
$i=0;
while($row = mysqli_fetch_array($result))
{


  $twitter="$row[twitter]";
  
   


  print"
      <div> $twitter</div>
  ";} ?>

              

                </div>
              </div>

              
            </div>
          </div>
        </div>
        
      </footer>
    </div>
    <script
      src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=652427491a917cefc5a160de"
      type="text/javascript"
      integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
      crossorigin="anonymous"
    ></script>
    <!-- <script
      src="https://assets-global.website-files.com/652427491a917cefc5a160de/js/webflow.6a5ed4a4d.js"
      type="text/javascript"
    ></script> -->
    <script src="./index.js" type="text/javascript"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/@srexi/purecounterjs/dist/purecounter_vanilla.js"></script>
    <script>
      new PureCounter({
        // Setting that can't' be overriden on pre-element
        selector: ".videos", // HTML query selector for spesific element

        // Settings that can be overridden on per-element basis, by `data-purecounter-*` attributes:
        start: 940, // Starting number [unit]
        end: 1000, // End number [unit]
        duration: 5, // The time in seconds for the animation to complete [seconds]
        delay: 10, // The delay between each iteration (the default of 10 will produce 100 fps) [miliseconds]
        once: true, // Counting at once or recount when the element in view [boolean]
        repeat: false, // Repeat count for certain time [boolean:false|seconds]
        decimals: 0, // How many decimal places to show. [unit]
        legacy: true, // If this is true it will use the scroll event listener on browsers
        filesizing: false, // This will enable/disable File Size format [boolean]
        currency: false, // This will enable/disable Currency format. Use it for set the symbol too [boolean|char|string]
        separator: false, // This will enable/disable comma separator for thousands. Use it for set the symbol too [boolean|char|string]
      });

      new PureCounter({
        // Setting that can't' be overriden on pre-element
        selector: ".subscribers", // HTML query selector for spesific element

        // Settings that can be overridden on per-element basis, by `data-purecounter-*` attributes:
        start: 0, // Starting number [unit]
        end: 10, // End number [unit]
        duration: 5, // The time in seconds for the animation to complete [seconds]
        delay: 10, // The delay between each iteration (the default of 10 will produce 100 fps) [miliseconds]
        once: true, // Counting at once or recount when the element in view [boolean]
        repeat: false, // Repeat count for certain time [boolean:false|seconds]
        decimals: 0, // How many decimal places to show. [unit]
        legacy: true, // If this is true it will use the scroll event listener on browsers
        filesizing: false, // This will enable/disable File Size format [boolean]
        currency: false, // This will enable/disable Currency format. Use it for set the symbol too [boolean|char|string]
        separator: false, // This will enable/disable comma separator for thousands. Use it for set the symbol too [boolean|char|string]
      });

      new PureCounter({
        // Setting that can't' be overriden on pre-element
        selector: ".views", // HTML query selector for spesific element

        // Settings that can be overridden on per-element basis, by `data-purecounter-*` attributes:
        start: 75, // Starting number [unit]
        end: 100, // End number [unit]
        duration: 5, // The time in seconds for the animation to complete [seconds]
        delay: 10, // The delay between each iteration (the default of 10 will produce 100 fps) [miliseconds]
        once: true, // Counting at once or recount when the element in view [boolean]
        repeat: false, // Repeat count for certain time [boolean:false|seconds]
        decimals: 0, // How many decimal places to show. [unit]
        legacy: true, // If this is true it will use the scroll event listener on browsers
        filesizing: false, // This will enable/disable File Size format [boolean]
        currency: false, // This will enable/disable Currency format. Use it for set the symbol too [boolean|char|string]
        separator: false, // This will enable/disable comma separator for thousands. Use it for set the symbol too [boolean|char|string]
      });
    </script>

    <script>
      //start video-carousel.js

$(document).ready(function(){

var $root = $(".video-carousel-root"),
    $slider = $root.find(".video-carousel-slider"),
    $slides = $slider.children("div"),
    slideWidth = $slides.width(),
    $leftButton = $root.find(".video-carousel-button-left"),
    $rightButton = $root.find(".video-carousel-button-right"),
    $allSlideButtons = $root.find(".video-carousel-button-left, .video-carousel-button-right"),
    $slideText = $root.find(".video-carousel-text"),
    isAnimating = false,
    transition = {"left":slideLeftTransition,"right":slideRightTransition},
    slideTimer, myPlayer, video_counter=0;

setClasses();
setText();

if (!supportsTransitions()) transition = {"left":slideLeftNoTransition,"right":slideRightNoTransition};
$allSlideButtons.click(slideButtonClick);
$leftButton.click(transition.left);
$rightButton.click(transition.right);
$leftSlide.click(transition.left);
$rightSlide.click(transition.right);
//slideTimer = setInterval(transition.right, 7000);

function slideButtonClick(){
    clearInterval(slideTimer);
    destroyVideoPlayer();
}
function slideLeftNoTransition(){
    $slider.prepend($slides.last());
    setClasses();
    setText();
}
function slideRightNoTransition(){
    $slider.append($slides.first());
    setClasses();
    setText();
}
function slideLeftTransition(){
    if(isAnimating) return;
    isAnimating = true;
    $slideText.empty();

    $slider.css("left", -slideWidth + "px");
    $slider.prepend($slides.last());
    setClasses();
    $slider.animate({left:"0px"}, 500, function(){
        setText();
        isAnimating = false;
    });
}
function slideRightTransition(){
    if(isAnimating) return;
    isAnimating = true;
    $slideText.empty();

    $slider.append($slides.first());
    setClasses();
    $slider.prepend($slides.last().clone());
    $slides = $slider.children("div");
    $slider.animate({left:-slideWidth + "px"}, 500, function(){
        $slides.eq(0).remove();
        setClasses();
        $slider.css("left", "0px");
        setText();
        isAnimating = false;
    });
}


function setClasses(){
    $slides = $slider.children("div");
    $slides.removeClass();
    $slides.eq(0).addClass("level1");
    $slides.eq(1).addClass("level2");
    $slides.eq(2).addClass("level3");
    $slides.eq(3).addClass("level2");
    $slides.eq(4).addClass("level1");
    
  var $slideButtonLeft = $slides.eq(1).find ("buttonme"),
      $slideButtonRight = $slides.eq(3).find ("buttonme");
    
    $slideButtonLeft.on("click", function(){
      slideButtonClick();
      transition.left();
      console.log("Left");
    });
  
  $slideButtonRight.on("click", function(){
      slideButtonClick(); 
      transition.right();
      console.log("Right");
    });
    $slides.off("click");
    $slides.eq(2).on("click", function(){
  var $this = $(this),
    player_id = $this.attr("id");
        clearInterval(slideTimer);
        createVideoPlayer($this.attr("data-vimeo-id"));
        
  dataLayer.push({'event': 'gaPushEvent','gaEventCategory': dataLayer[0].siteVersion+'_homepage','gaEventAction': 'click','gaEventLabel': player_id});

        video_counter ++;
        var s=s_gi(omniture_rsid);s.linkTrackVars = 'eVar5,eVar7,events';s.eVar5 = video_counter;s.eVar7 = player_id;s.linkTrackEvents="event5";s.events = 'event5';s.tl(this, 'o', 'Home');
    });
    $slides.eq(1).on("click", function(){
      slideButtonClick();
      transition.left();
      console.log("Left");
    });
    $slides.eq(3).on("click", function(){
      slideButtonClick(); 
      transition.right();
      console.log("Right");
    });
}
function setText(){
    $slideText.html($slides.eq(2).find("p").html());
}

function createVideoPlayer(source){
    var $container = $slides.eq(2).find(".panel"),
        playerWidth = $container.width(),
        playerHeight = $container.height(),
        $iframe = $("<iframe class='video' src='//player.vimeo.com/video/"+source+"?title=0&byline=0&portrait=0' width='300' height='168' frameborder='0' webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>");

    $container.append($iframe);
    myPlayer = $f($iframe[0]);
    $slides.eq(2).off("click");
    myPlayer.addEvent('ready', function() {
        myPlayer.api("play");
        myPlayer.addEvent('finish', destroyVideoPlayer);
    });
}
function destroyVideoPlayer(){
    if(myPlayer){
        var $slide = $slides.eq(2);
        myPlayer.api("pause");
        myPlayer = null;
        $slide.find("iframe").remove();
        $slides.eq(2).on("click", function(){
            createVideoPlayer($(this).attr("data-vimeo-id"));
        });
    }
}

function supportsTransitions() {
    var b = document.body || document.documentElement,
        s = b.style,
        p = 'transition';
    if (typeof s[p] == 'string') { return true; }

    // Tests for vendor specific prop
    var v = ['Moz', 'webkit', 'Webkit', 'Khtml', 'O', 'ms'];
    p = p.charAt(0).toUpperCase() + p.substr(1);
    for (var i=0; i<v.length; i++) {
        if (typeof s[v[i] + p] == 'string') { return true; }
    }
    return false;
}
});

//start jquery-carousel3.js

(function($) {

$.fn.carousel = function(options) {
    return this.each(function () {
        var $root = $(this),
            $slides = $root.children().addClass("slide"),
            $viewport = $("<div class='viewport'/>").appendTo($root),
            $slideContainer = $("<div class='slides'/>").append($slides).appendTo($viewport),
            $pager = $("<div class='pager'/>").appendTo($root),
            $arrowPrevious = $("<div class='arrow arrow-previous'/>").appendTo($viewport),
            $arrowNext = $("<div class='arrow arrow-next'/>").appendTo($viewport),
            $pagerButtons,
            defaults = {showPager:true},
            settings = $.extend({}, defaults, options);

        if(settings.showPager) buildPager();
        showSlide(0);
        $root.show();

        $arrowPrevious.click(function () {
            showSlide($slideContainer.find(".selected").index() - 1);
        });
        $arrowNext.click(function () {
            showSlide($slideContainer.find(".selected").index() + 1);
        });

        function buildPager() {
            for (var i = 0, len = $slides.length; i < len; i++) {
                $pager.append("<div class='pager-button'></div>");
            }
            $pagerButtons = $root.find(".pager-button");
            $pagerButtons.click(function () {
                showSlide($(this).index())
            });
        }

        function showSlide(index) {
            if (index == -1) index = $slides.length - 1;
            else if (index == $slides.length) index = 0;

            $slides.removeClass("selected");
            $slides.eq(index).addClass("selected");

            if(settings.showPager){
                $pagerButtons.removeClass("selected");
                $pagerButtons.eq(index).addClass("selected");
            }
        }
    });
};
}(jQuery));

//start mobile-video-carousel-nopage.js
$(document).ready(function(){

var $videoMobileRoot = $(".videos-mobile-root"),
    $slider = $videoMobileRoot.find(".slider"),
    $slides = $videoMobileRoot.find(".slide"),
    $players = $slides.find("iframe"),
    $arrowLeft = $videoMobileRoot.find(".arrow-left"),
    $arrowRight = $videoMobileRoot.find(".arrow-right"),
$allButtons = $videoMobileRoot.find(".arrow-left,.arrow-right"),
    slideWidth = $slides.width(),
    sliderTimer = setInterval(slideRight, 7000),
    isAnimating, allPlayers = [], video_counter=0;

  
//Click Events
$allButtons.click(function(){clearInterval(sliderTimer); stopPlayers();});
$arrowLeft.click(slideLeft);
$arrowRight.click(slideRight);

function slideLeft(){
    var currentIndex = parseInt($slider.css("left")) / -slideWidth;
    if(currentIndex == 0) slideTo($slides.length - 1);
    else slideTo(currentIndex - 1);
}
function slideRight(){
    var currentIndex = parseInt($slider.css("left")) / -slideWidth;
    if(currentIndex == $slides.length - 1) slideTo(0);
    else slideTo(currentIndex + 1);
}
function slideTo(index){
    if(isAnimating) return;
    isAnimating = true;
    $slider.animate({"left":-slideWidth * index},500, function(){
        isAnimating = false;
    });
}

$(window).resize(function(){
    slideWidth = $slides.width();        
});

$players.each(function(){
var currentPlayer = $f(this);
allPlayers.push(currentPlayer);
currentPlayer.addEvent('ready', playerReady);
});	
function playerReady(player_id){
var player = $f(player_id);
player.addEvent('ready', function() {
  player.addEvent('play', function(e){
    clearInterval(sliderTimer);				

    //ga('send', 'event', 'v1_homepage', 'video', player_id);
            dataLayer.push({'event': 'gaPushEvent','gaEventCategory': dataLayer[0].siteVersion+'_homepage','gaEventAction': 'click','gaEventLabel': player_id});
    
            video_counter ++;
            var s=s_gi(omniture_rsid);s.linkTrackVars = 'eVar5,eVar7,events';s.eVar5 = video_counter;s.eVar7 = player_id;s.linkTrackEvents="event5";s.events = 'event5';s.tl(this, 'o', 'Home');
    
  });
    });
}
function stopPlayers(){
    var i= 0, len = allPlayers.length;
    for(i; i<len; i++){
        allPlayers[i].api("pause");
    }
}

});



    </script>
    
  </body>
</html>
